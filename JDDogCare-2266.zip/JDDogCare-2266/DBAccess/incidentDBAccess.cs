﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class incidentDBAccess
    {
        private DataBase db;
        public incidentDBAccess(DataBase DB)
        {
            db = DB;
        }

        public List<Tuple<Incident, Repercussions>> getIncidentsViaDog(int dogID, DateTime date)
        {
            List<Tuple<Incident, Repercussions>> results = new List<Tuple<Incident, Repercussions>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT I.Info, R.Banned, R.CostIncrease FROM Incident AS I INNER JOIN Repercussions AS R ON I.[RepercussionsID*] = R.RepercussionsID WHERE[I.DogID*]= '" + dogID + "'I.Date= '" + date.ToString("MM/dd/yyyy") + "'";
            db.Rdr = db.Cmd.ExecuteReader();
            try
            {
                while (db.Rdr.Read())
                {
                    results.Add(getInnerJoin(db.Rdr));
                }
            }
            catch
            {

            }
            return results;
        }
        public List<Tuple<Incident, Dogs>> getIncidentsViaDate(DateTime date)
        {
            List<Tuple<Incident, Dogs>> results = new List<Tuple<Incident, Dogs>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.DogName, I.Info FROM Incident AS I INNER JOIN Dogs AS D ON I.[DogID*] = D.DogID WHERE I.Date= '" + date.ToString("MM/dd/yyyy") + "'";
            db.Rdr = db.Cmd.ExecuteReader();
            try
            {
                while (db.Rdr.Read())
                {
                    results.Add(getIncidentsFromReader(db.Rdr));
                }
            }
            catch
            {

            }
            return results;
        }
        public Tuple<Incident, Dogs> getIncidentsFromReader(SqlDataReader rdr)
        {
            Incident incident = new Incident();
            Dogs dogs = new Dogs();
            dogs.Dogname = rdr.GetString(0);
            incident.Info = rdr.GetString(1);
            Tuple<Incident, Dogs> results = new Tuple<Incident, Dogs>(incident, dogs);
            return results;
        }
        public Tuple<Incident, Repercussions> getInnerJoin(SqlDataReader reader)
        {
            Tuple<Incident, Repercussions> results;
            Incident incidentData = new Incident();
            Repercussions reprecussionsData = new Repercussions();
            incidentData.Info = db.Rdr.GetString(0);
            reprecussionsData.Banned = db.Rdr.GetBoolean(1);
            reprecussionsData.Cost = db.Rdr.GetInt32(2);
            results = new Tuple<Incident, Repercussions>(incidentData, reprecussionsData);
            return results;

        }
        public bool generateIncident( int dogID, int repercussionsID,string info, DateTime dateOfIncident)
        {
            db.connect();
            string COMMAND = "INSERT INTO Incident VALUES (Incident.[DogID*], Incident.[RepercussionsID*], Incident.Info, IncidentDate) VALUES ("+dogID+", "+repercussionsID+", '"+info+"', '"+dateOfIncident.ToString("MM/dd/yyyy")+"')";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }

        }
    }
}
