﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class ClientDBAccess
    {

        private DataBase db;
        public ClientDBAccess(DataBase DB)
        {
            db = DB;
        }
        public ClientDBAccess(DataBase DB, string clientName)
        {
            db = DB;
        }
        public ClientDBAccess()
        {

        }
        public bool createClient(string Name, string AddressOne, string AddressTwo, string PostCode, string PaymentType)
        {
            db.connect();
            string COMMAND = "INSERT INTO Client (ClientName, AddressLineOne, AddressLineTwo, PostCode, PaymentType) VALUES ('" + Name + "','" + AddressOne + "','" + AddressTwo + "','" + PostCode + "', '" + PaymentType + "')";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool deleteClient(int clientID)
        {
            db.connect();
            string COMMAND = "DELETE Client WHERE ClientID="+clientID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public int getClientID(string name, string addressLineOne) {
            int results;
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT C.ClientID FROM Client AS C WHERE C.ClientName LIKE'"+name+"' AND C.AddressLineOne LIKE '"+addressLineOne+"'";
            db.Rdr = db.Cmd.ExecuteReader();
            db.Rdr.Read();
            results = db.Rdr.GetInt32(0);
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public List<Client> getAllClients()
        {
            List<Client> clients = new List<Client>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT C.ClientID, C.ClientName FROM Client AS C";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                clients.Add(GetClient(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return clients;
        }
        public Client GetClient(SqlDataReader reader)
        {
            Client results = new Client();
            results.ClientID = reader.GetInt32(0);
            results.Clientname = reader.GetString(1);
            return results;
        }
        public List<Tuple<Dogs, Client, Booking, Billing>> GetAllClientsInfo(string searchTerm)
        {
            textValidation textValidation = new textValidation(searchTerm);
            searchTerm = textValidation.results;
            List<Tuple<Dogs, Client, Booking, Billing>> results = new   List<Tuple<Dogs, Client, Booking, Billing>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.DogName, C.ClientName,B.EmergancyCare,C.ClientID, D.DogID, B.BookingID FROM Booking AS B INNER JOIN Client AS C ON B.[ClientID*] = C.ClientID INNER JOIN dogToOwner AS DTO ON DTO.[clientID*] = C.ClientID INNER JOIN Dogs as D ON DTO.[dogID*] = D.DogID WHERE (D.DogName) like '" + searchTerm + "%' OR C.ClientName like '"+ searchTerm + "%'";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getInnerJoinFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Tuple<Dogs, Client, Booking, Billing> getInnerJoinFromReader(SqlDataReader reader)
        {
            Dogs dogData = new Dogs();
            Client clientData = new Client();
            Booking bookingData = new Booking();
            Billing billingData = new Billing();
            dogData.Dogname = db.Rdr.GetString(0);
            clientData.Clientname = db.Rdr.GetString(1);
            bookingData.EmergancyCare = db.Rdr.GetBoolean(2);
            clientData.ClientID = db.Rdr.GetInt32(3);
            dogData.DogID = db.Rdr.GetInt32(4);
            bookingData.BookingID = db.Rdr.GetInt32(5);
            Tuple<Dogs, Client, Booking, Billing > results = new Tuple<Dogs, Client, Booking, Billing>(dogData, clientData, bookingData, billingData);
            return results;
        }
        public bool checkForDuplicateEntery(string clientName, string addressLineOne, string addressLineTwo, string postcode, string paymentType)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM Client WHERE ClientName = '"+ clientName+ "' AND AddressLineOne = '" + addressLineOne + "' AND AddressLineTwo = '" + addressLineTwo + "' AND PostCode = '" + postcode + "' AND PaymentType = '" + paymentType +"' ";
            try
            {
                db.Rdr = db.Cmd.ExecuteReader();
                db.Rdr.Read();
                string name = db.Rdr.GetString(0);
                db.Rdr.Close();
                db.Conn.Close();
                return true;
            }
            catch
            {
                db.Rdr.Close();
                db.Conn.Close();
                return false;
            }
        }
    }
}
