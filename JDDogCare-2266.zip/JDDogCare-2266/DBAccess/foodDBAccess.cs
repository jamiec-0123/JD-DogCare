﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class foodDBAccess
    {
        DataBase db;
        public foodDBAccess(DataBase db)
        {
            this.db = db;
        }
        public List<Food> getAllFood()
        {
            List<Food> results = new List<Food>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT F.Food, F.FoodID FROM Food AS F";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getAllFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Food getAllFromReader(SqlDataReader rdr)
        {
            Food results = new Food();
            results.FoodInfo = rdr.GetString(0);
            results.FoodID = rdr.GetInt32(1);
            return results;
        }
    }
}
