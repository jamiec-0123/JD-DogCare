﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class servicesDBAccess
    {
        private DataBase db;
        public servicesDBAccess(DataBase DB)
        {
            this.db = DB;
        }
        public List<services> getAllSerivces()
        {
            List<services> results = new List<services>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM Services";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getAllFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public services getAllFromReader(SqlDataReader rdr)
        {
            services results = new services();
            results.serviceId = rdr.GetInt32(0);
            results.cost = rdr.GetDouble(1);
            results.Info =  rdr.GetString(2);
            return results;
        }
    }
}
