﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class DogDBAcess
    {

        private DataBase db;
        public DogDBAcess(DataBase DB)
        {
            db = DB;
        }
        public DogDBAcess()
        {

        }
        public List<Tuple<Dogs, staff, Activity, Booking>> GetAllDog(DateTime selectedDate)
        {
            List<Tuple<Dogs, staff, Activity, Booking>> results = new List<Tuple<Dogs, staff, Activity, Booking>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.DogName, S.StaffMember,  A.Activity,b.DateStart, b.DateEnd FROM [Group] AS T INNER JOIN Dogs AS D ON T.GroupID = D.GroupID INNER JOIN Staff AS S ON T.StaffID = S.StaffID INNER JOIN dogToOwner AS DTO ON D.DogID = DTO.dogID INNER JOIN Booking AS B ON DTO.ClientID = B.[ClientID*]  INNER JOIN Activity AS A ON T.Activity = A.[Activity ID] WHERE b.DateStart <= '" + selectedDate.ToString("MM/dd/yyyy") + "' AND '" + selectedDate.ToString("MM/dd/yyyy") + "' <= b.DateEnd";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getInnerJoinFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Tuple<Dogs, staff, Activity, Booking> getInnerJoinFromReader(SqlDataReader reader)
        {
            Dogs dogData = new Dogs();
            staff staffData = new staff();
            Booking bookingData = new Booking();
            Activity activityData = new Activity();
            dogData.Dogname= db.Rdr.GetString(0);
            staffData.Name= db.Rdr.GetString(1);
            activityData.Name = db.Rdr.GetString(2);
            bookingData.DateStart = db.Rdr.GetDateTime(3);
            bookingData.DateEnd = db.Rdr.GetDateTime(4);
            Tuple<Dogs, staff, Activity, Booking> results = new Tuple<Dogs, staff, Activity, Booking>(dogData,staffData,activityData,bookingData);

            return results;
        }
        public int getLatestDogID(string DogName)
        {
            int results;
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.DogID FROM Dogs AS D WHERE DogName LIKE '" + DogName + "' ORDER BY D.DogID DESC";
            db.Rdr = db.Cmd.ExecuteReader();
            db.Rdr.Read();
            results = db.Rdr.GetInt32(0);
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public List<Dogs> getAllDogsNames()
        {
            List<Dogs> results = new List<Dogs>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.DogID, D.DogName FROM Dogs AS D";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getDogsFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Dogs getDogsFromReader(SqlDataReader rdr)
        {
            Dogs dogData = new Dogs();
            dogData.DogID = db.Rdr.GetInt32(0);
            dogData.Dogname = db.Rdr.GetString(1);
            return dogData;
        }
        public bool createDog(string Name, int food)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            string COMMAND = "INSERT INTO Dogs(DogName, [FoodID*]) VALUES ( '"+Name+"' , "+food+")";
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool deleteDog(int dogID)
        {
            db.connect();
            string COMMAND = "DELETE Dogs WHERE DogID=" + dogID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
    }
}
