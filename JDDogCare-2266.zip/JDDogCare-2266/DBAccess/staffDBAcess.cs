﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class staffDBAcess
    {
        private DataBase db;
        public staffDBAcess(DataBase DB)
        {
            db = DB;
        }

        public List<staff> getAllStaffNamesAndIDs()
        {
            List<staff> results = new List<staff>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM Staff";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(GetStaffFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public staff GetStaffFromReader(SqlDataReader Rdr)
        {
            staff results = new staff();
            results.staffID = db.Rdr.GetInt32(0);
            results.Name = db.Rdr.GetString(1);
            results.Morning = Rdr.GetBoolean(2);
            results.Afternoon = Rdr.GetBoolean(3);
            for (int currentIndex = 0; currentIndex < 5; currentIndex++)
            {
                results.setDayOfWeek(currentIndex, Rdr.GetBoolean(4 + currentIndex));
            }
            return results;
        }
        public List<Tuple<staff>> getStaffBetweenDate(DateTime selectedDate)
        {
            List<Tuple<staff>> results = new List<Tuple<Objects.staff>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT S.StaffMember, S.FullTime FROM [Staff] AS S FULL OUTER JOIN staffOffDuty AS staffOff ON S.StaffID =  staffOff.staffOffID WHERE S.StaffID !=  COALESCE((SELECT (staffOffDuty.staffOffID ) FROM staffOffDuty WHERE (staffOffDuty.startDate <= '" + selectedDate.ToString("MM/dd/yyyy") + "' AND '" + selectedDate.ToString("MM/dd/yyyy") + "' <= staffOffDuty.EndDate )), 0) AND ( S.FullTime =1 OR S.StaffID =  COALESCE((SELECT (staffOffDuty.staffReplacementID ) FROM staffOffDuty WHERE (staffOffDuty.startDate <= '" + selectedDate.ToString("MM/dd/yyyy") + "' AND '" + selectedDate.ToString("MM/dd/yyyy") + "' <= staffOffDuty.EndDate )), 0) )";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getInnerJoinFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public int getStaffBetweenStartEndDate(DateTime startDate, DateTime endDate)
        {
            int results;
            db.connect();
            db.Cmd = db.Conn.CreateCommand();//startDate.ToString("MM/dd/yyyy")
            db.Cmd.CommandText = "SELECT Count(*) FROM Booking as b where " + startDate.ToString("MM/dd/yyyy") + " > DateStart AND " + endDate.ToString("MM/dd/yyyy") + " <b.DateEnd";
            db.Rdr = db.Cmd.ExecuteReader();
            results = db.Rdr.GetInt32(0);
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Tuple<staff> getInnerJoinFromReader(SqlDataReader reader)
        {
            staff staffData = new staff();
            staffData.Name = db.Rdr.GetString(0);
            //staffData.fullTime = db.Rdr.GetBoolean(1);
            Tuple<staff> results = new Tuple<staff>(staffData);
            return results;
        }
        public bool addStaff(string name, int[] weekdays, int[] time)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO Staff(Staff.StaffName, Staff.morning, Staff.evening, Staff.mon, Staff.tues, Staff.wednes, Staff.thurs, Staff.fri) VALUES ('" + name + "'," + time[0] + "," + time[1] + "," + weekdays[0] + "," + weekdays[1] + "," + weekdays[2] + "," + weekdays[3] + "," + weekdays[4] + ")";
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }

        }
    }
}

