﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class vaccinesDBAccess
    {
        DataBase db;
        public vaccinesDBAccess(DataBase db)
        {
            this.db = db;
        }
        
        public List<Vaccines> getAllVaccines()
        {
            List<Vaccines> results = new List<Vaccines>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT V.Name, V.VaccinesID FROM Vaccines AS V";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getFromReader());
            }
            db.Conn.Close();
            db.Rdr.Close();
            return results;
        }
        public Vaccines getFromReader()
        {
            Vaccines results = new Vaccines();
            results.Name = db.Rdr.GetString(0);
            results.VaccineID = db.Rdr.GetInt32(1);
            return results;
        }
        public bool updateVTDTable(int vacID, int dogID)
        {
            db.connect();
            string COMMAND = "INSERT INTO VacinationToDog([vaccineID*], [dogID*]) VALUES ("+vacID+", "+dogID + ")";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
    }
}
