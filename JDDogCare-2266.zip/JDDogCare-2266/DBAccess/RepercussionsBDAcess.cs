﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class RepercussionsBDAcess
    {
        DataBase DB;
        //List<>
        public RepercussionsBDAcess(DataBase DB)
        {
            this.DB = DB;
        }
        public List<Repercussions> getAll()
        {
            List<Repercussions> results = new List<Repercussions>();
            DB.connect();
            DB.Cmd = DB.Conn.CreateCommand();
            DB.Cmd.CommandText = "SELECT R.RepercussionsID, R.CostIncrease FROM Repercussions AS R";
            DB.Rdr = DB.Cmd.ExecuteReader();
            while (DB.Rdr.Read())
            {
                results.Add(getFromReader(DB.Rdr));
            }
            DB.Rdr.Close();
            DB.Conn.Close();
            return results;
        }
        public Repercussions getFromReader(SqlDataReader rdr)
        {
            Repercussions results = new Repercussions();
            results.ReprecussionsID = rdr.GetInt32(0);
            results.Cost = rdr.GetInt32(1);
            return results;
        }
    }
}
