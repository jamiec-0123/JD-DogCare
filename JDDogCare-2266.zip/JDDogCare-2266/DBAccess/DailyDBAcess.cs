﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class DailyDBAcess
    {
        private DataBase db;
        public DailyDBAcess(DataBase DB)
        {
            db = DB;
        }
        public List<Tuple<Dogs, staff, Daily>> getDay(DateTime selectedDate)
        {
            List<Tuple<Dogs, staff, Daily>> results = new List<Tuple<Dogs, staff, Daily> >();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT D.Fed, D.NoOfWalks, Dog.DogName, Dog.currentHealthy, s.StaffName, s.morning, s.evening, s.mon,s.tues, s.wednes, s.thurs, s.fri FROM Daily AS D INNER JOIN DogS AS Dog ON D.[DogID*] = Dog.DogID INNER JOIN Food AS F ON Dog.[FoodID*] = f.FoodID INNER JOIN Staff AS S ON D.[StaffID*] = S.StaffID WHERE D.Date ='" + selectedDate.ToString("MM/dd/yyyy")+"'";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getInnerJoinFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Tuple<Dogs,staff, Daily> getInnerJoinFromReader(SqlDataReader reader)
        {
            Dogs dogsData = new Dogs();
            staff staffData = new staff();
            Daily dailyData = new Daily();
            dailyData.Fed = reader.GetBoolean(0);
            dailyData.noOfWalks = reader.GetInt32(1);
            dogsData.Dogname = reader.GetString(2);
            staffData.Name = reader.GetString(3);
            staffData.Morning = reader.GetBoolean(4);
            staffData.Afternoon = reader.GetBoolean(5);
            staffData.setDayOfWeek(0, reader.GetBoolean(6));
            staffData.setDayOfWeek(1, reader.GetBoolean(7));
            staffData.setDayOfWeek(2, reader.GetBoolean(8));
            staffData.setDayOfWeek(3, reader.GetBoolean(9));
            staffData.setDayOfWeek(4, reader.GetBoolean(10));
            Tuple<Dogs, staff, Daily> results = new Tuple<Dogs, staff, Daily>(dogsData,staffData,dailyData);
            return results;
        }
    }
}
