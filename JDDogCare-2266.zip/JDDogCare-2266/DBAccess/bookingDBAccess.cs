﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class bookingDBAccess
    {
        private DataBase db;
        public bookingDBAccess(DataBase DB)
        {
            db = DB;
        }
        public bool createBooking(int clientID, int dogID,int billingID, bool emergancyCare, DateTime start, DateTime end)
        {
            db.connect();
            string COMMAND = "INSERT INTO Booking ( Booking.[ClientID*], Booking.[DogID*], Booking.[BillingID*], Booking.EmergancyCare, Booking.DateStart, Booking.DateEnd) VALUES (" + clientID + "," +dogID+","+billingID+"," + Convert.ToInt32( emergancyCare) + ",'" + start.ToString("MM/dd/yyyy") + "', '" + end.ToString("MM/dd/yyyy") + "')";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool checkExcistingBooking(int clientID)
        {
            db.connect();
            string COMMAND = "SELECT * FROM Booking WHERE [ClientID*] =" + clientID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Rdr = db.Cmd.ExecuteReader();
                int id = db.Rdr.GetInt32(0);
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public List<Tuple<Dogs, Food>> getBetweenDate(DateTime date)
        {
            List<Tuple<Dogs, Food>> results = new List<Tuple<Dogs, Food>>(); 
            db.connect();
            string COMMAND = "SELECT D.DogName, D.Trial, F.Food FROM Booking AS B INNER JOIN Dogs AS D ON B.[DogID*] = D.DogID INNER JOIN Food AS F ON D.[FoodID*] = F.FoodID WHERE '" + date.ToString("MM/dd/yyyy") +"' BETWEEN B.DateStart and B.DateEnd";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getBetweenDatesFromReader(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;

        }
        public Tuple<Dogs, Food> getBetweenDatesFromReader(SqlDataReader rdr)
        {
            Dogs dogs = new Dogs();
            Food food = new Food();
            dogs.Dogname = rdr.GetString(0);
            dogs.Trial = rdr.GetBoolean(1);
            food.FoodInfo = rdr.GetString(2);
            Tuple<Dogs, Food> results = new Tuple<Dogs, Food>(dogs,food);
            return results;
        }
        public bool deleteBooking(int bookingID)
        {
            db.connect();
            string COMMAND = "DELETE Booking WHERE BookingID=" + bookingID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
    }
}
