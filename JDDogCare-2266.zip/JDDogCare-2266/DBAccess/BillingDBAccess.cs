﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class BillingDBAccess
    {
        private DataBase db;
        public BillingDBAccess(DataBase DB)
        {
            db = DB;
        }

        public List<Tuple<Booking, Billing, services, Client, Dogs, Repercussions>> getAllBillings()
        {
            List<Tuple<Booking, Billing, services, Client, Dogs, Repercussions>> results = new List<Tuple<Booking, Billing, services, Client, Dogs, Repercussions>>();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT Bill.NoOfPrintOuts, Bill.DatePayed, S.Cost, S.Info, Booking.DateStart, Booking.DateEnd, Booking.EmergancyCare, C.ClientName, D.DogName , r.CostIncrease, Bill.DatePayed FROM Billing AS Bill INNER JOIN [Booking] ON Bill.BillingID = Booking.[BillingID*]  INNER JOIN [Services] AS S ON Bill.ServicesID = S.ServicesID  INNER JOIN [dogToOwner] AS DTO ON Booking.[ClientID*] =  DTO.[clientID*] AND Booking.[DogID*] = DTO.[dogID*]  INNER JOIN [Client] AS C ON DTO.[clientID*] = C.ClientID  INNER JOIN [Dogs] AS D ON DTO.[dogID*] = D.DogID INNER JOIN [Incident] AS I ON D.DogID = I.[DogID*] INNER JOIN Repercussions AS R ON i.[RepercussionsID*] = r.RepercussionsID ";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getInnerJoin(db.Rdr));
            }
            db.Rdr.Close();
            db.Conn.Close();
            return results;
        }
        public Tuple<Booking, Billing, services, Client, Dogs, Repercussions> getInnerJoin(SqlDataReader rdr)
        {
            Booking bookingData = new Booking();
            Billing feesData = new Billing();
            services servicesData = new services();
            Client clientData = new Client();
            Dogs dogData = new Dogs();
            Repercussions RepercussionsData = new Repercussions();
            feesData.noOfIssued = rdr.GetInt32(0);
            feesData.DatePayed = rdr.GetDateTime(1);
            servicesData.cost = rdr.GetInt32(2);
            bookingData.DateStart = rdr.GetDateTime(3);
            bookingData.DateEnd = rdr.GetDateTime(4);
            bookingData.EmergancyCare = rdr.GetBoolean(5);
            clientData.Clientname = rdr.GetString(6);
            dogData.Dogname = rdr.GetString(7);
            RepercussionsData.Cost = rdr.GetDecimal(8);
            feesData.BookingID = rdr.GetInt32(9);
            Tuple<Booking, Billing, services, Client, Dogs, Repercussions> results = new Tuple<Booking, Billing, services,Client, Dogs, Repercussions>(bookingData, feesData, servicesData,clientData, dogData, RepercussionsData);
            return results;
        }
        public bool createFees(int servicesID)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            string COMMAND = "INSERT INTO [JD-DogCare].[dbo].[Billing]  ([Billing].ServicesID) VALUES (" + servicesID + ")";
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool updatePayment(int paymentID)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            string COMMAND = "UPDATE Billing AS B SET B.DatePayed = '01/01/1990' WHERE B.BillingID=(" + paymentID + ")";
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool updatePayment(int paymentID, DateTime datePayed)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            string COMMAND = "UPDATE Billing AS B SET B.DatePayed = "+datePayed.ToString("MM/dd/yyyy") + " WHERE B.BillingID=(" +paymentID+ ")";
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool payBill(DateTime now, int billingID)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            string COMMAND = "INSERT INTO Booking  AS B (B.DatePayed) VALUES ('" + now.ToString("MM/dd/yyyy") +":00') WHERE BillingID ="+billingID+"";
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public int getLatestFeesID()
        {
            int results;
            db.connect();
            string COMMAND = "SELECT B.BillingID FROM Billing  AS B ORDER BY B.BillingID DESC";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            db.Rdr = db.Cmd.ExecuteReader();
            db.Rdr.Read();
            results = db.Rdr.GetInt32(0);
            return results;
        }



        public List<Tuple<Booking, Client>> getAllMiessedPayment()
        {
            List<Tuple<Booking, Client>> results = new List<Tuple<Booking, Client>>();
            db.connect();
            string COMMAND = "SELECT C.ClientName, B.DateEndFROM Booking  AS B INNER JOIN Client AS C ON B.[ClientID*] = C.ClientID INNER JOIN Booking ON C.ClientID = Booking.[ClientID*] WHERE BILL.DatePayed = '01/01/1990'";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getMissedPaymentInnerJoin(db.Rdr));
            }
            return results;
        }
        public bool getClientMissedPayments(int clientID)
        {
            List<Tuple<Booking, Client>> results = new List<Tuple<Booking, Client>>();
            db.connect();
            string COMMAND = "SELECT C.ClientName, B.DateEnd FROM Booking AS B INNER JOIN Client AS C ON B.[ClientID*] = C.ClientID INNER JOIN Billing AS BILL ON B.[BillingID*] = BILL.BillingID WHERE BILL.DatePayed = '01/01/1990' AND C.ClientID =" + clientID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            db.Cmd.ExecuteReader();
            try
            {
                while (db.Rdr.Read())
                {
                    results.Add(getMissedPaymentInnerJoin(db.Rdr));
                }
                return (true);
            }
            catch
            {
                return (false);
            }
        }
        public Tuple<Booking, Client> getMissedPaymentInnerJoin(SqlDataReader rdr)
        {
            Booking bookngData = new Booking();
            Client clientData = new Client();

            clientData.Clientname = rdr.GetString(0);
            bookngData.DateEnd = rdr.GetDateTime(1);
            //billingData
            Tuple<Booking, Client> results = new Tuple<Booking, Client>(bookngData, clientData);
            return results;
        }
    }
}
