﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;

namespace JDDogCare_2266.DBAccess
{
    class vaccinesToDogDBAccess 
    {
        DataBase db;
        public vaccinesToDogDBAccess(DataBase db)
        {
            this.db = db;
        }
        public bool deleteDog(int dogID)
        {
            db.connect();
            string COMMAND = "DELETE VacinationToDog WHERE VacinationToDog.[dogID*] =" + dogID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
    }
}
