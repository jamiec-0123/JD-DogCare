﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;


namespace JDDogCare_2266.DBAccess
{
    class dogToOwnersDBAcess
    {
        private DataBase db;
        public dogToOwnersDBAcess(DataBase DB)
        {
            db = DB;
        }
        public bool createLink(int clientID, int dogID)
        {
            db.connect();
            string COMMAND = "INSERT INTO dogToOwner([clientID*], [dogID*]) VALUES  (" + clientID + ", " + dogID + ")";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool getLinkForIDs(int clientID, int dogID)
        {
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM dogToOwner AS D WHERE D.[ClientID*] =" + clientID + " AND D.[DogID*] =" + dogID + "";
            try
            {
                db.Rdr = db.Cmd.ExecuteReader();
                db.Rdr.Read();
                db.Rdr.GetInt32(0);
                db.Rdr.GetInt32(1);
                db.Conn.Close();
                return true;
            }
            catch
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool deleteBasedOnDogID(int dogID)
        {
            db.connect();
            string COMMAND = "DELETE dogToOwner WHERE  dogToOwner.[dogID*] =" + dogID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool deleteBasedOnClientID(int clientID)
        {
            db.connect();
            string COMMAND = "DELETE dogToOwner WHERE [clientID*] =" + clientID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = COMMAND;
            try
            {
                db.Cmd.ExecuteNonQuery();
                db.Conn.Close();
                return true;
            }
            catch (Exception)
            {
                db.Conn.Close();
                return false;
            }
        }
        public bool checkForDogIDLink(string DogName, int clientID)
        {
            int results;
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT* FROM dogToOwner AS DTO INNER JOIN Client AS C ON DTO.[clientID*] = C.ClientID INNER JOIN Dogs AS D ON DTO.[dogID*] = D.DogID WHERE DogName LIKE '" + DogName + "' AND C.ClientID = " + clientID;
            try
            {
                db.Rdr = db.Cmd.ExecuteReader();
                results = db.Rdr.GetInt32(0);
                db.Rdr.Close();
                db.Conn.Close();
                return true;
            }
            catch
            {
                db.Rdr.Close();
                db.Conn.Close();
                return false;
            }
        }
    }
}
