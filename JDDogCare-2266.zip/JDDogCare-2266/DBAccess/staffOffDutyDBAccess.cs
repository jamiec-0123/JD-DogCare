using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using System.Data.SqlClient;


namespace JDDogCare_2266.DBAccess
{
    class staffOffDutyDBAccess
    {
        private DataBase db;
        public staffOffDutyDBAccess(DataBase DB)
        {
            db = DB;
        }
        
        public staff getStaffOn(int offID)
        {
            staff newstaffAcc = new staff();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM Staff WHERE staffID=" + offID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                newstaffAcc.staffID = db.Rdr.GetInt32(0);
                newstaffAcc.Name = db.Rdr.GetString(1);
            }
            db.Rdr.Close();
            db.Conn.Close();
            return newstaffAcc;
        }
        //STAFF MONDAY TUES WEDNS THRUS FRI SAT SUN  COLMNS TO BE ADDED
        public staff addStaff(int offID, DateTime start)
        {
            staff newstaffAcc = new staff();
            db.connect();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM Staff WHERE staffID=" + offID;
            //future work to be done here
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                newstaffAcc.staffID = db.Rdr.GetInt32(0);
                newstaffAcc.Name = db.Rdr.GetString(1);
            }
            db.Rdr.Close();
            db.Conn.Close();
            return newstaffAcc;
        }
    }
}