﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class StaffOffDuty
    {
        private int _refernceID, _StaffID;
        private DateTime _startDate, _endDate;


        public StaffOffDuty(DateTime StartDate, int StaffID)
        {
            this.StaffID = StaffID;
            this.StartDate = StartDate;
        }
        public StaffOffDuty(DateTime StartDate, DateTime EndDate,int StaffID)
        {
            this.StaffID = StaffID;
            this.StartDate = StartDate;
            this.EndDate = EndDate;
        }
        public StaffOffDuty(DateTime StartDate, DateTime EndDate)
        {
            this.StartDate = StartDate;
            this.EndDate = EndDate;
        }
        public StaffOffDuty(DateTime StartDate)
        {
            this.StartDate = StartDate;
        }
        public StaffOffDuty(int StaffID, int RefernceID)
        {
            this.StaffID = StaffID;
            this.RefernceID = RefernceID;
        }
        public StaffOffDuty(int StaffID)
        {
            this.StaffID = StaffID;
        }

        public StaffOffDuty()
        {

        }

        public int RefernceID
        {
            get { return _refernceID; }
            set { _refernceID = value; }
        }
        public int StaffID
        {
            get { return _StaffID; }
            set { _StaffID = value; }
        }
        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }
        public DateTime EndDate
        {
            get { return _endDate; }
            set { _endDate = value; }
        }
    }
}
