﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class Daily
    {
        private int _dailyRefernceID, _noOfWaklks, _staffID,_dogID;
        private bool _fed;
        private DateTime _date;

        public Daily(DateTime Date, int DailyRefernceID)
        {
            this.Date = Date;
            this.DailyRefernceID = DailyRefernceID;
        }
        public Daily(int DailyRefernceID)
        {
            this.DailyRefernceID = DailyRefernceID;
        }
        public Daily(DateTime Date)
        {
            this.Date = Date;
        }
        public Daily()
        {

        }

        public int DailyRefernceID
        {
            get { return _dailyRefernceID; }
            set { _dailyRefernceID = value; }
        }

        public int noOfWalks
        {
            get { return _noOfWaklks; }
            set { _noOfWaklks = value; }
        }

        public int  DogID
        {
            get { return _dogID; }
            set { _dogID = value; }
        }

        public int StaffID
        {
            get { return _staffID; }
            set { _staffID = value; }
        }
        public bool Fed
        {
            get { return _fed; }
            set { _fed = value; }
        }
        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }
    }
}
