﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class services
    {

        private double _cost;
        private int _serviceId;
        private string _info;

        //Constructor
        public services(string Info, double cost, int serviceId)
        {
            this.Info = Info;
            this.cost = cost;
            this.serviceId = serviceId;
        }
        public services(string Info)
        {
            this.Info = Info;
        }
        public services(int serviceId)
        {
            this.serviceId = serviceId;
        }

        //Default Constructor
        public services()
        {
        }

        //Properties
        public double cost
        {
            get { return _cost; }
            set { _cost = value; }
        }

        public int serviceId
        {
            get { return _serviceId; }
            set { _serviceId = value; }
        }
        public string Info
        {
            get { return _info; }
            set { _info = value; }
        }
    }
}
