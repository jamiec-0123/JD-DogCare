﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    public class Client
    {
        private int _ClientId, _noOfLates;
        private string _Clientname, _PaymentType, _address;


        //Constructor
        public Client(int ClientID, int NoOfLates, string Clientname, string PaymentType)
        {
            this.NoOfLates = NoOfLates;
            this.ClientID = ClientID;
            this.Clientname = Clientname;
            this.PaymentType = PaymentType;
        }
        public Client(string Clientname, string PaymentType)
        {
            this.Clientname = Clientname;
            this.PaymentType = PaymentType;
        }
        public Client(string Clientname, int NoOfLates)
        {
            this.NoOfLates = NoOfLates;
            this.Clientname = Clientname;
        }
        public Client(int ClientID, string PaymentType)
        {
            this.PaymentType = PaymentType;
            this.ClientID = ClientID;
        }
        public Client(int ClientID, int NoOfLates)
        {
            this.NoOfLates = NoOfLates;
            this.ClientID = ClientID;
        }
        public Client(string Clientname)
        {
            this.Clientname = Clientname;
        }
        public Client(int ClientID)
        {
            this.ClientID = ClientID;
        }

        //Default Constructor
        public Client()
        {
        }


        public int ClientID
        {
            get { return _ClientId; }
            set { _ClientId = value; }
        }
        public int NoOfLates
        {
            get { return _noOfLates; }
            set { _noOfLates =value; }
        }
        
        public string Clientname
        {
            get { return _Clientname; }
            set { _Clientname = value; }
        }
        public string PaymentType
        {
            get { return _PaymentType; }
            set { _PaymentType = value; }
        }
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
    }
}
