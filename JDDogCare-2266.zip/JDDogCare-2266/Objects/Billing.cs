﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    public class Billing
    {
        private int _bookingID, _billingID, _NoOfIssued;
        private string _services;
        private DateTime _DateLastIssued, _DatePayed;
        public Billing()
        {
        }
        public Billing(int BookingID, int BillingID)
        {
            this.BookingID = BookingID;
            this.BillingID = BillingID;
        }
        public Billing(string ServicesID, int BookingID, int BillingID)
        {
            this.ServicesID = ServicesID;
            this.BookingID = BookingID;
            this.BillingID = BillingID;
        }
        public int BillingID
        {
            get { return _billingID; }
            set { _billingID = value;}
        }
        public int BookingID
        {
            get { return _bookingID; }
            set { _bookingID = value; }
        }
        public int noOfIssued
        {
            get { return _NoOfIssued; }
            set { _NoOfIssued = value; }
        }
       public string ServicesID
        {
            get { return _services; }
            set { _services = value; }
        }
        public DateTime DateLastIssued
        {
            get { return _DateLastIssued; }
            set { _DateLastIssued = value; }
        }
        public DateTime DatePayed
        {
            get { return _DatePayed; }
            set { _DatePayed = value; }
        }
    }
}
