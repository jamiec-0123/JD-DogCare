﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class Incident
    {
        private int _incidentID, _dogID, _reprecussionsID;
        private string _info;
        private DateTime _date;
        public Incident(int IncidentID, int DogID, int ReprecussionsID)
        {

        }
        public Incident(DateTime Date)
        {
            this.Date = Date;
        }
        public Incident()
        {

        }
        public int IncidentID
        {
            get { return _incidentID; }
            set { _incidentID = value; }
        }
        public int DogID
        {
            get { return _dogID; }
            set { _dogID = value; }
        }
        public int RepecussionsID
        {
            get { return _reprecussionsID; }
            set { _reprecussionsID = value; }
        }
        public string Info
        {
            get { return _info; }
            set { _info = value; }
        }
        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }
    }
}
