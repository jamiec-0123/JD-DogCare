﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    public class Booking
    {
        private int _BookingID, _ClientID, _services;
        private bool _EmergancyCare;
        private DateTime _dateStart, _dateEnd;


        //Constructor
        public Booking(int BookingID, int ClientID, int services, bool EmergancyCare, DateTime DateStart, DateTime DateEnd)
        {
            this.BookingID = BookingID;
            this.ClientID = ClientID;
            this.services = services;
            this.EmergancyCare = EmergancyCare;
            this.DateStart = DateStart;
            this.DateEnd = DateEnd;
        }
        public Booking(int BookingID, int ClientID, int services, bool EmergancyCare)
        {
            this.BookingID = BookingID;
            this.ClientID = ClientID;
            this.services = services;
            this.EmergancyCare = EmergancyCare;
        }
        public Booking(int ClientID, int services, DateTime DateStart, DateTime DateEnd)
        {
            this.ClientID = ClientID;
            this.services = services;
            this.DateStart = DateStart;
            this.DateEnd = DateEnd;
        }
        public Booking(int ClientID, int services)
        {
            this.ClientID = ClientID;
        }
        public Booking(int BookingID,DateTime DateStart, DateTime DateEnd)
        {
            this.DateStart = DateStart;
            this.DateEnd = DateEnd;
            this.BookingID = BookingID;
        }
        public Booking(int BookingID)
        {
            this.BookingID = BookingID;
        }
        public Booking(DateTime DateStart, DateTime DateEnd)
        {
            this.DateStart = DateStart;
            this.DateEnd = DateEnd;
        }
        //Default Constructor
        public Booking()
        {
        }
        //Get sets
        public int BookingID
        {
            get { return _BookingID; }
            set { _BookingID = value; }
        }
        public int ClientID
        {
            get { return _ClientID; }
            set { _ClientID = value; }
        }
        public int services
        {
            get { return _services; }
            set { _services = value; }
        }

        public bool EmergancyCare
        {
            get { return _EmergancyCare; }
            set { _EmergancyCare = value; }
        }

        public DateTime DateStart
        {
            get { return _dateStart; }
            set { _dateStart = value; }
        }
        public DateTime DateEnd
        {
            get { return _dateEnd; }
            set { _dateEnd = value; }
        }

    }
}
