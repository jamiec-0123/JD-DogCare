﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class staff
    {
        private int _staffId;
        private string _name;
        private bool _morning, _afternoon;
        private bool[] daysOfWeek = new bool[5];
        //Constructor
        public staff(int staffID, string name)
        {
            this.staffID = staffID;
            Name = name;
        }

        //Default Constructor
        public staff()
        {
        }


        public int staffID
        {
            get { return _staffId; }
            set { _staffId = value; }
        }

        public string Name {
            get { return _name; }
            set { _name = value; }
        }
        public bool Morning
        {
            get { return _morning; }
            set { _morning = value; }
        }
    
        public bool Afternoon
        {
            get { return _afternoon; }
            set { _afternoon = value; }
        }
        public void setDayOfWeek(int index, bool value)
        {
            daysOfWeek[index] = value;
        }
        public bool getDayOfWeek(int indexer)
        {
             return daysOfWeek[indexer]; 
        }
}
}
