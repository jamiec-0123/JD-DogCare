﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    public class Dogs
    {
        private int _DogId, _FoodID;
        private string _Dogname;
        private bool _Trial;

        //Constructor
        public Dogs(int DogID, string Dogname, int FoodID, bool Trial)
        {
            this.DogID = DogID;
            this.Dogname = Dogname;
            this.FoodID = FoodID;
            this.Trial = Trial;
        }
        public Dogs(int DogID, string Dogname, int FoodID)
        {
            this.DogID = DogID;
            this.Dogname = Dogname;
            this.FoodID = FoodID;
        }
        public Dogs(int DogID, string Dogname)
        {
            this.DogID = DogID;
            this.Dogname = Dogname;
        }
        public Dogs(int DogID)
        {
            this.DogID = DogID;

        }

        //Default Constructor
        public Dogs()
        {
        }


        public int DogID
        {
            get { return _DogId; }
            set { _DogId = value; }
        }

        public string Dogname
        {
            get { return _Dogname; }
            set { _Dogname = value; }
        }
        public int FoodID
        {
            get { return _FoodID; }
            set { _FoodID = value; }
        }
        public bool Trial
        {
            get { return _Trial; }
            set { _Trial = value; }
        }

    }
}
