﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class DogsToOwners
    {
        private int _DogID, _ClientID;
        public DogsToOwners(int DogID, int ClientID)
        {
            this.ClientID = ClientID;
            this.DogID = DogID;
        }
        public DogsToOwners()
        {

        }
        public int DogID
        {
            get { return _DogID; }
            set { _DogID = value; }
        }
        public int ClientID
        {
            get { return _ClientID; }
            set { _ClientID = value; }
        }
    }
}
