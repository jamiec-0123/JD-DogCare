﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class Food
    {
        private int _foodID;
        private string _foodInfo;
        public Food(int FoodID, string FoodInfo)
        {
            this.FoodInfo = FoodInfo;
            this.FoodID = FoodID;
        }
        public Food(int FoodID)
        {
            this.FoodID = FoodID;
        }
        public Food()
        {

        }
        public string FoodInfo
        {
            get { return _foodInfo; }
            set { _foodInfo = value; }
        }
        public int FoodID
        {
            get { return _foodID; }
            set { _foodID = value; }
        }
    }
}
