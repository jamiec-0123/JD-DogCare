﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    public class Repercussions
    {
        private int _reprecussionsID;
        private bool _banned;
        private decimal _cost;

        public Repercussions(int ReprecussionsID, bool Banned, decimal Cost)
        {
            this.ReprecussionsID = ReprecussionsID;
            this.Banned = Banned;
            this.Cost = Cost;
        }

        public Repercussions(int ReprecussionsID)
        {
            this.ReprecussionsID = ReprecussionsID;
        }

        public Repercussions()
        {

        }
        public int ReprecussionsID
        {
            get { return _reprecussionsID; }
            set { _reprecussionsID = value; }
        }
        public bool Banned
        {
            get { return _banned; }
            set { _banned = value; }
        }
        public decimal Cost
        {
            get { return _cost; }
            set { _cost = value; }
        }
    }
}
