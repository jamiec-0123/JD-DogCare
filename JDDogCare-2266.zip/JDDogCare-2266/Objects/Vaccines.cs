﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class Vaccines
    {
        private int _vaccineID;
        private string _name;

        public Vaccines(int VaccineID, string Name)
        {
            this.VaccineID = VaccineID;
            this.Name = Name;
        }
        public Vaccines(int VaccineID)
        {
            this.VaccineID = VaccineID;
        }
        public Vaccines(string Name)
        {
            this.Name = Name;
        }
        public Vaccines()
        {

        }
        public int VaccineID
        {
            get { return _vaccineID; }
            set { _vaccineID = value; }
        }
        public string Name
        {
            get{return _name; }
            set{_name =value;}
        }
    }
}
