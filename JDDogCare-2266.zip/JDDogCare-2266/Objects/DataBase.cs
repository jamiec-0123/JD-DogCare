﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace JDDogCare_2266.Objects
{
    public class DataBase
    {
        private SqlCommand cmd;
        private SqlConnection conn;
        private SqlDataReader rdr;

        //default constructor
        public DataBase()
        {

        }
        
        public SqlCommand Cmd
        {
            get { return cmd; }
            set { cmd = value; }
        }

        public SqlConnection Conn
        {
            get { return conn; }
            set { conn = value; }
        }

        public SqlDataReader Rdr
        {
            get { return rdr; }
            set { rdr = value; }
        }

        //Methods
        public bool connect()
        {
            SqlConnectionStringBuilder scStrBuild = new SqlConnectionStringBuilder();
            scStrBuild.DataSource = ".\\SQLEXPRESS"; 
            scStrBuild.InitialCatalog = "2266-JD-DogCare";
            scStrBuild.IntegratedSecurity = true;
            conn = new SqlConnection(scStrBuild.ToString());
            try
            {
                conn.Open();
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex);
            }

            if (conn.State == ConnectionState.Open)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
