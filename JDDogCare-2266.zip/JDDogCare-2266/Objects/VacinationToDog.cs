﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class VacinationToDog
    {
        private int _VTDRefernceID, _vaccineID, _dogID;

        public VacinationToDog(int VTDRefernceID,int VaccineID, int DogID)
        {
            this.VTDRefernceID = VTDRefernceID;
            this.VaccineID = VaccineID;
            this.DogID = DogID;
        }
        public VacinationToDog(int DogID, int VaccineID)
        {
            this.DogID = DogID;
            this.VaccineID = VaccineID;

        }
        public VacinationToDog(int VTDRefernceID)
        {
            this.VTDRefernceID = VTDRefernceID;
        }
        public VacinationToDog()
        {

        }
        public int VTDRefernceID
        {
            get { return _VTDRefernceID; }
            set { _VTDRefernceID = value; }
        }
        public int VaccineID
        {
            get { return _vaccineID; }
            set { _vaccineID = value; }
        }
        public int DogID
        {
            get { return _dogID; }
            set { _dogID = value; }
        }
    }
}
