﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDDogCare_2266.Objects
{
    class Activity
    {
        private int _ActivityId;
        private string _name;


        //Constructor
        public Activity(int ActivityID, string Name)
        {
            this.ActivityID = ActivityID;
            this.Name = Name;
        }
        public Activity(int ActivityID)
        {
            this.ActivityID = ActivityID;
        }

        //Default Constructor
        public Activity()
        {
        }


        public int ActivityID
        {
            get { return _ActivityId; }
            set { _ActivityId = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }
}
