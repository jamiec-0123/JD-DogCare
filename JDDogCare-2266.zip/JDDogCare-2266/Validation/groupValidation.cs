﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;

namespace JDDogCare_2266.Validation
{
    class groupValidation
    {
        public groupValidation()
        {

        }
       
    }
}
