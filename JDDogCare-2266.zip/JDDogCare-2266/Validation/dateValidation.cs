﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.Validation
{
    class dateValidation
    {
        private DateTime _testDate;
        private string _startDate, _endDate;
        public List<DateTime> bankTime;

        public dateValidation()
        {
            generateBankHolidays();
        }
        public int initialTest(string dateTime)
        {

            try
            {
                testDate = DateTime.Parse(dateTime);
            }
            catch
            {
                return 1;
            }
            if (testDate.Year > DateTime.Now.Year-2)
            {
                return 2;
            }
            else if (testDate.Year < DateTime.Now.Year + 5)
            {
                return 3;
            }
            else
            {
                return 0;
            }
        }
        public bool attemptBooking(string testStartDate, string testEndDate, DataBase db)
        {
            if (initialTest(StartDate) == 0 && initialTest(EndDate) == 0)
            {
            staffDBAcess staffInfo = new staffDBAcess(db);
            DateTime startDate = DateTime.Parse(testStartDate);
            DateTime endDate = DateTime.Parse(testEndDate);
                if (staffInfo.getStaffBetweenStartEndDate(startDate, endDate) >= 6)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else { return false; }
        }
        public void generateBankHolidays()
        {

            string[] lines = System.IO.File.ReadAllLines("./../bankHoliday.txt");
            int index = 1;
            int year = 0, month = 0;
            bankTime = new List<DateTime>();
            foreach (string line in lines)
            {
                if (index == 1)
                {
                    year = Convert.ToInt32(line);
                }
                else if (index == 2)
                {
                    month = Convert.ToInt32(line);
                }
                else
                {
                    bankTime.Add(new DateTime(year, month, Convert.ToInt32(line)));
                    index = 0;
                }
                index++;
            }
        }

        public int BusinessDaysUntil(DateTime firstDay, DateTime lastDay)
        {
            firstDay = firstDay.Date;
            lastDay = lastDay.Date;
            if (firstDay > lastDay)
            {
                throw new ArgumentException("Incorrect last day " + lastDay);
            }
            TimeSpan span = lastDay - firstDay;
            int businessDays = span.Days + 1;
            int fullWeekCount = businessDays / 7;
            // find out if there are weekends during the time exceedng the full weeks
            if (businessDays > fullWeekCount * 7)
            {
                // we are here to find out if there is a 1-day or 2-days weekend
                // in the time interval remaining after subtracting the complete weeks
                int firstDayOfWeek = firstDay.DayOfWeek == DayOfWeek.Sunday
                    ? 7 : (int)firstDay.DayOfWeek;
                //here sunday will be 7 instead of 0
                int lastDayOfWeek = lastDay.DayOfWeek == DayOfWeek.Sunday
                    ? 7 : (int)lastDay.DayOfWeek;
                if (lastDayOfWeek < firstDayOfWeek)
                    lastDayOfWeek += 7;
                if (firstDayOfWeek <= 6)
                {
                    if (lastDayOfWeek >= 7)// Both Saturday and Sunday are in the remaining time interval
                        businessDays -= 2;
                    else if (lastDayOfWeek >= 6)// Only Saturday is in the remaining time interval
                        businessDays -= 1;
                }
                else if (firstDayOfWeek <= 7 && lastDayOfWeek >= 7)// Only Sunday is in the remaining time interval
                    businessDays -= 1;
            }

            // subtract the weekends during the full weeks in the interval
            businessDays -= fullWeekCount + fullWeekCount;

            // subtract the number of bank holidays during the time interval
            foreach (DateTime bankHoliday in bankTime)
            {
                DateTime bh = bankHoliday.Date;
                if (firstDay <= bh && bh <= lastDay)
                    --businessDays;
            }
            return businessDays;
        }
        public List<DateTime> highLightDays(DateTime start, int NoOfDays)
        {
            List<DateTime> results = new List<DateTime>();
            int index = 0;
            while (index < NoOfDays)
            {
                if (BusinessDaysUntil(start, start) != 0)
                {
                    results.Add(start);
                    index++;
                }
                start = start.AddDays(1);
            }

            return results;
        }



        public DateTime testDate
        {
            get{ return _testDate; }
            set { _testDate = value; }
        }
        public string StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }
        public string EndDate
        {
            get { return _endDate; }
            set { _endDate = value; }
        }
    }
}
