﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace JDDogCare_2266.Validation
{
    class textValidation
    {
        public string results;
        public textValidation()
        {

        }
        public textValidation(string dataBaseInput)
        {
            removeSQLInjection(dataBaseInput);
        }
        public string removeSQLInjection(string dataBaseInput)
        {

            char[] test = dataBaseInput.ToCharArray();
            results = "";
            foreach (char data in test)
            {
                if (data == (char)(39))
                {
                    results += "''";
                }
                else
                {
                    results += data;
                }
            }
            return results;
        }
        public bool checkForNonLetters(string testData)
        {
            char[] testingGroup = testData.ToCharArray();
            foreach (char data in testingGroup)
            {
                if (data > (char)(33) && data < (char)(64) || data > (char)(122))
                {
                    return false;
                }
            }
            return true;

        }
        public bool checkForNonLettersOrNumbers(string testData)
        {
            char[] testingGroup = testData.ToCharArray();
            foreach (char data in testingGroup)
            {
                if (data > (char)(33) && data < (char)(47) || data > (char)(122))
                {
                    return false;
                }
                else
                {
                    if(data > (char)(58) && data < (char)(64))
                    {
                        return false;
                    }
                    else
                    {
                        if (data > (char)(91) && data < (char)(96))
                        {
                            return false;
                        }

                    }
                }
            }
            return true;

        }
        public string valName(string testData)
        {
            string results = "";
            char[] testingGroup = testData.ToCharArray();
            if (testingGroup.Length < 2)
            {
                results = "ERROR";
            }
            else if (testingGroup.Length > 40)
            {
                results = "ERROR";
            }
            else
            {
                if (!checkForNonLetters(testData))
                {
                    results = "ERROR";
                }
                else
                {
                    results = removeSQLInjection(testData);
                }
            }
            return results;
        }
        public string valAdressLine(string testData)
        {
            string results = "";
            char[] testingGroup = testData.ToCharArray();
            if (testingGroup.Length < 2)
            {
                results = "ERROR";
            }
            else if (testingGroup.Length > 50)
            {
                results = "ERROR";
            }
            else
            {
                if (!checkForNonLettersOrNumbers(testData))
                {
                    results = "ERROR";
                }
                else
                {
                    results = removeSQLInjection(testData);
                }
            }
            return results;

        }
        public string valPostCode(string testData)
        {
            string results = "";
            char[] testingGroup = testData.ToCharArray();
            if (testingGroup.Length < 2)
            {
                results = "ERROR";
            }
            else if (testingGroup.Length > 10)
            {
                results = "ERROR";
            }
            else
            {
                if (!checkForNonLettersOrNumbers(testData))
                {
                    results = "ERROR";
                }
                else
                {
                    results = removeSQLInjection(testData);
                }
            }
            return results;
        }
    }
}
