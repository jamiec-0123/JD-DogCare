﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;

namespace JDDogCare_2266.GUI
{
    public partial class construction : defaultScreen
    {
        public construction()
        {
            InitializeComponent();
            base.CurrentScreen=0;
        }
    }
}
