﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class staffTimeOff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startPickerDTP = new System.Windows.Forms.DateTimePicker();
            this.endPickerDTP = new System.Windows.Forms.DateTimePicker();
            this.staffCB = new System.Windows.Forms.ComboBox();
            this.cancleBTN = new System.Windows.Forms.Button();
            this.updateBTN = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // startPickerDTP
            // 
            this.startPickerDTP.Location = new System.Drawing.Point(372, 71);
            this.startPickerDTP.Name = "startPickerDTP";
            this.startPickerDTP.Size = new System.Drawing.Size(200, 20);
            this.startPickerDTP.TabIndex = 0;
            // 
            // endPickerDTP
            // 
            this.endPickerDTP.Location = new System.Drawing.Point(372, 97);
            this.endPickerDTP.Name = "endPickerDTP";
            this.endPickerDTP.Size = new System.Drawing.Size(200, 20);
            this.endPickerDTP.TabIndex = 1;
            // 
            // staffCB
            // 
            this.staffCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.staffCB.FormattingEnabled = true;
            this.staffCB.Location = new System.Drawing.Point(12, 96);
            this.staffCB.Name = "staffCB";
            this.staffCB.Size = new System.Drawing.Size(354, 21);
            this.staffCB.TabIndex = 11;
            this.staffCB.Tag = "NoneGrayable";
            // 
            // cancleBTN
            // 
            this.cancleBTN.Location = new System.Drawing.Point(407, 149);
            this.cancleBTN.Name = "cancleBTN";
            this.cancleBTN.Size = new System.Drawing.Size(75, 23);
            this.cancleBTN.TabIndex = 12;
            this.cancleBTN.Text = "Cancel";
            this.cancleBTN.UseVisualStyleBackColor = true;
            this.cancleBTN.Click += new System.EventHandler(this.CancleBTN_Click);
            // 
            // updateBTN
            // 
            this.updateBTN.Location = new System.Drawing.Point(488, 149);
            this.updateBTN.Name = "updateBTN";
            this.updateBTN.Size = new System.Drawing.Size(75, 23);
            this.updateBTN.TabIndex = 13;
            this.updateBTN.Text = "Update";
            this.updateBTN.UseVisualStyleBackColor = true;
            this.updateBTN.Click += new System.EventHandler(this.updateBTN_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox3);
            this.panel1.Controls.Add(this.checkBox2);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Location = new System.Drawing.Point(372, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 23);
            this.panel1.TabIndex = 14;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(141, 3);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(56, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Month";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.Month_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(80, 4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(55, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Week";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.Week_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(29, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(45, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Day";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.Day_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Select Staff";
            // 
            // staffTimeOff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 177);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.updateBTN);
            this.Controls.Add(this.cancleBTN);
            this.Controls.Add(this.staffCB);
            this.Controls.Add(this.endPickerDTP);
            this.Controls.Add(this.startPickerDTP);
            this.Name = "staffTimeOff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staff Time Off";
            this.Load += new System.EventHandler(this.AddStaff_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker startPickerDTP;
        private System.Windows.Forms.DateTimePicker endPickerDTP;
        private System.Windows.Forms.Button cancleBTN;
        private System.Windows.Forms.Button updateBTN;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox staffCB;
    }
}