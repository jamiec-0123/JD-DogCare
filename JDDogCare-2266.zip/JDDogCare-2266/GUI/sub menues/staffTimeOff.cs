﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.DBAccess;
using JDDogCare_2266.Objects;

namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class staffTimeOff : MaterialSkin.Controls.MaterialForm
    {
        List<staff> staffData = new List<staff>();
        staffDBAcess staffDB;
        DataBase db;
        public staffTimeOff(DataBase db)
        {
            this.db = db;
            InitializeComponent();
        }

        private void AddStaff_Load(object sender, EventArgs e)
        {
            staffDB = new staffDBAcess(db);
            staffData = staffDB.getAllStaffNamesAndIDs();
            foreach (staff data in staffData)
            {
                staffCB.Items.Add(data.Name);
            }
        }

        private void updateBTN_Click(object sender, EventArgs e)
        {

        }

        private void CancleBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Month_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Day_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Week_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
