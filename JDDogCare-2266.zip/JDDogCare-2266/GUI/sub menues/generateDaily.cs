﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using JDDogCare_2266.DBAccess;


namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class generateDaily : MaterialSkin.Controls.MaterialForm
    {
        private List<Tuple<Dogs, staff, Daily>> dbDailyData;
        private List<Tuple<Dogs,Food>> dbDogsData;
        //staffOffDutyDBAccess staffOffDutyDB;
        //staffDBAcess staffDB;
        //DogDBAcess dogDB;
        DailyDBAcess DailyDB;
        bookingDBAccess bookingDB;
        private dateValidation validationDate;

        DataTable staff;
        DataTable dogs;
        DataTable daily;

        DataBase db;
        public generateDaily(DataBase db)
        {
            //staffOffDutyDB = new staffOffDutyDBAccess(db);
            //staffDB = new staffDBAcess(db);
            //dogDB = new DogDBAcess(db);
            validationDate = new dateValidation();
            DailyDB = new DailyDBAcess(db);
            bookingDB = new bookingDBAccess(db);
            staff = new DataTable();
            dogs = new DataTable();
            daily = new DataTable();
            InitializeComponent();

            daily.Columns.Add("Dog Name");
            daily.Columns.Add("Staff Member");
            daily.Columns.Add("Fed");
            daily.Columns.Add("No OfWalks");
            dogs.Columns.Add("Name");
            dogs.Columns.Add("Trail");
            dogs.Columns.Add("Food Needed");
            staff.Columns.Add("Staff Name");
            staff.Columns.Add("Morning");
            staff.Columns.Add("Afternoon");
            dogsSheet.DataSource = dogs;
            dayCareSheet.DataSource = daily;
            staffOnDuty.DataSource = staff;
            this.db = db;
        }
        public void updateTables()
        {
            staff = new DataTable();
            dogs = new DataTable();
            daily = new DataTable();
            daily.Columns.Add("Dog Name");
            daily.Columns.Add("Staff Member");
            daily.Columns.Add("Fed");
            daily.Columns.Add("No OfWalks");
            dogs.Columns.Add("Name");
            dogs.Columns.Add("Trail");
            dogs.Columns.Add("Food Needed");
            staff.Columns.Add("Staff Name");
            staff.Columns.Add("Morning");
            staff.Columns.Add("Afternoon");
            if (validationDate.BusinessDaysUntil(dateTimePicker.Value, dateTimePicker.Value) > 0)
            {
                dbDailyData = DailyDB.getDay(dateTimePicker.Value);
                dbDogsData = bookingDB.getBetweenDate(dateTimePicker.Value);
                foreach (Tuple<Dogs, staff, Daily> dayCareData in dbDailyData)
                {
                    daily.Rows.Add(dayCareData.Item1.Dogname, dayCareData.Item2.Name, dayCareData.Item3.Fed, dayCareData.Item3.noOfWalks);
                    //dogs.Rows.Add(dayCareData.Item1.Dogname);
                    staff.Rows.Add(dayCareData.Item2.Name, dayCareData.Item2.Morning.ToString(), dayCareData.Item2.Afternoon.ToString());
                }
                foreach (Tuple<Dogs, Food> dogData in dbDogsData)
                {
                    dogs.Rows.Add(dogData.Item1.Dogname,dogData.Item1.Trial.ToString(), dogData.Item2.FoodInfo);
                }

            }
            else
            {
                MessageBox.Show("Appologies but the day care is closed on bank holidays and weekends", "Weekend or bankholiday selected");
            }
            dogsSheet.DataSource = dogs;
            dayCareSheet.DataSource = daily;
            staffOnDuty.DataSource = staff;
        }

        private void generateDaily_Load(object sender, EventArgs e)
        {

        }

        private void UpdateSelectionBTN_Click(object sender, EventArgs e)
        {

            /*
                        for (int vacNum = 1; vacNum < vaccineDGV.Rows.Count; vacNum++)
                        {
                            if (vaccineDGV.Rows[vacNum - 1].Selected == true)
                            {
                                vaccinesDB.updateVTDTable(vacNum, dogID);
                            }
                        }

                         */
        }

        private void RemoveLinkBTN_Click(object sender, EventArgs e)
        {

        }

        private void SaveBTN_Click(object sender, EventArgs e)
        {

        }

        private void CancelBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new mainMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void DateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            updateTables();
        }
    }
}
