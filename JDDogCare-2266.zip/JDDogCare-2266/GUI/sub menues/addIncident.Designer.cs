﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class addIncident
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dogsCB = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.repercussionCB = new System.Windows.Forms.ComboBox();
            this.issueTXT = new System.Windows.Forms.TextBox();
            this.updateBTN = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cancleBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dogsCB
            // 
            this.dogsCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dogsCB.FormattingEnabled = true;
            this.dogsCB.Location = new System.Drawing.Point(13, 83);
            this.dogsCB.Name = "dogsCB";
            this.dogsCB.Size = new System.Drawing.Size(208, 21);
            this.dogsCB.TabIndex = 2;
            this.dogsCB.Tag = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Select Reprocussion";
            // 
            // repercussionCB
            // 
            this.repercussionCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.repercussionCB.FormattingEnabled = true;
            this.repercussionCB.Location = new System.Drawing.Point(12, 162);
            this.repercussionCB.Name = "repercussionCB";
            this.repercussionCB.Size = new System.Drawing.Size(209, 21);
            this.repercussionCB.TabIndex = 6;
            this.repercussionCB.Tag = "NoneGrayable";
            // 
            // issueTXT
            // 
            this.issueTXT.Location = new System.Drawing.Point(12, 123);
            this.issueTXT.Name = "issueTXT";
            this.issueTXT.Size = new System.Drawing.Size(209, 20);
            this.issueTXT.TabIndex = 7;
            // 
            // updateBTN
            // 
            this.updateBTN.Location = new System.Drawing.Point(146, 189);
            this.updateBTN.Name = "updateBTN";
            this.updateBTN.Size = new System.Drawing.Size(75, 23);
            this.updateBTN.TabIndex = 8;
            this.updateBTN.Text = "Update";
            this.updateBTN.UseVisualStyleBackColor = true;
            this.updateBTN.Click += new System.EventHandler(this.updateBTN_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Select dog";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Record issue";
            // 
            // cancleBTN
            // 
            this.cancleBTN.Location = new System.Drawing.Point(12, 189);
            this.cancleBTN.Name = "cancleBTN";
            this.cancleBTN.Size = new System.Drawing.Size(75, 23);
            this.cancleBTN.TabIndex = 11;
            this.cancleBTN.Text = "Cancel";
            this.cancleBTN.UseVisualStyleBackColor = true;
            this.cancleBTN.Click += new System.EventHandler(this.Close_Click);
            // 
            // addIncident
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 216);
            this.Controls.Add(this.cancleBTN);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.updateBTN);
            this.Controls.Add(this.issueTXT);
            this.Controls.Add(this.repercussionCB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dogsCB);
            this.Name = "addIncident";
            this.Text = "Incident Reporter";
            this.Load += new System.EventHandler(this.addIncident_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox dogsCB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox repercussionCB;
        private System.Windows.Forms.TextBox issueTXT;
        private System.Windows.Forms.Button updateBTN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button cancleBTN;
    }
}