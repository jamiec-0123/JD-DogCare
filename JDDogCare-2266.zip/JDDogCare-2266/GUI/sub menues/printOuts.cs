﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class printOuts : Form
    {
        public printOuts()
        {
            InitializeComponent();
        }
    }
}
