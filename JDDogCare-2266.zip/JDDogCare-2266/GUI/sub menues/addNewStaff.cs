﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class addNewStaff : MaterialSkin.Controls.MaterialForm
    {
        textValidation validation;
        DataBase DB;
        bool daySelected, timeSelected;
        staffDBAcess staffDB;
        int[] daySelect = new int[] { 0, 0, 0, 0, 0 };
        int[] timeSelect = new int[] { 0,1 };

        public addNewStaff(DataBase DB)
        {
            daySelected = false;
            this.DB = DB;
            staffDB = new staffDBAcess(DB);
            validation = new textValidation();
            InitializeComponent();
        }

        private void NameLBL_Click(object sender, EventArgs e)
        {
            nameLBL.Text = "";
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addStaff_Click(object sender, EventArgs e)
        {
            if(nameLBL.Text == "" || nameLBL.Text == "Enter Name")
            {
                MessageBox.Show("Please add the staffs name", "ERROR`");
            }
            else
            {
                string test = validation.valName(nameLBL.Text);
                if (test != "ERROR")
                {
                    int index = 0;
                    foreach (Control c in daysPanel.Controls)
                    {
                        if ((c is CheckBox))
                        {
                            if (((CheckBox)c).Checked) daySelect[index] = 1;
                            daySelected = true;
                            index++;
                        }
                    }
                    index = 0;
                    foreach (Control c in timePanel.Controls)
                    {
                        if (c is CheckBox)
                        {
                            if (((CheckBox)c).Checked) timeSelect[index] = 1;
                            timeSelected = true;
                            index++;
                        }
                    }
                    if (daySelected == true && timeSelected == true)
                    {
                        staffDB.addStaff(test,daySelect,timeSelect);
                        MessageBox.Show("Sucess!");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Neccicary tick boxes havent beeen updated", "ERROR");
                    }
                }
            }
        }
    }
}
