﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class updateFees : MaterialSkin.Controls.MaterialForm
    {

        public updateFees()
        {
            InitializeComponent();
        }

        private void CancleBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateFees_Load(object sender, EventArgs e)
        {

        }

        private void SaveBTN_Click(object sender, EventArgs e)
        {
            //check if work is unsaved
            DialogResult dialogResult = MessageBox.Show("Exit back to the billing table", "Exit", MessageBoxButtons.YesNo);
            if(dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {

            }
        }
    }
}
