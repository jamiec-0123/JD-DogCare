﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.GUI;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.GUI.sub_menues
    {
    public partial class addBooking : MaterialSkin.Controls.MaterialForm
    {
        DataBase db;

        bool selectedDate, dogSelected, clientSelected, errorCheck;
        int clientID, dogID, noOfDogs, selectedService, billingID;
        double runningCosts, discounts =1;
        string output, VALclientname, VALaddressLineOne, VALaddressLineTwo, VALdogName, VALpostcode;
        DataTable vaccinesTable, dogFoodTable, clientTable, dogTable;
        DateTime selectedStart, selectedEnd;

        List<services> servicesResults;
        List<Client> clientResults;
        List<Dogs> dogResults;
        List<Vaccines> VaccinesResults;
        List<Food> foodResults;

        bookingDBAccess bookingDB;
        BillingDBAccess billingDB;
        ClientDBAccess ClientDB;
        DogDBAcess DogDB;
        dogToOwnersDBAcess dogToOwnersDB;
        servicesDBAccess servicesDB;
        foodDBAccess foodDB;
        textValidation inputVal;
        dateValidation bookingThing;
        vaccinesDBAccess vaccinesDB;

        Thread forms;



        public addBooking(DataBase db)
        {
            this.db = db;

            ClientDB = new ClientDBAccess(db);
            DogDB = new DogDBAcess(db);
            dogToOwnersDB = new dogToOwnersDBAcess(db);
            bookingDB = new bookingDBAccess(db);
            billingDB = new BillingDBAccess(db);
            foodDB = new foodDBAccess(db);
            servicesDB = new servicesDBAccess(db);
            vaccinesDB = new vaccinesDBAccess(db);

            vaccinesTable = new DataTable();
            dogFoodTable = new DataTable();

            bookingThing = new dateValidation();
            inputVal = new textValidation();

            InitializeComponent();
            selectedDate = false;
        }
        private void AddClients_Load(object sender, EventArgs e)
        {
            this.paymentCB.DropDownStyle = ComboBoxStyle.DropDownList;
            this.servicesCB.DropDownStyle = ComboBoxStyle.DropDownList;

            servicesResults = new List<services>();
            servicesResults = servicesDB.getAllSerivces();
            foreach(services data in servicesResults)
            {
                servicesCB.Items.Add(data.Info);
            }

            VaccinesResults = new List<Vaccines>();
            VaccinesResults = vaccinesDB.getAllVaccines();
            vaccinesTable.Columns.Add("Vaccines name");
            foreach (Vaccines data in VaccinesResults)
            {
                vaccinesTable.Rows.Add(data.Name);
            }
            vaccineDGV.DataSource = vaccinesTable;

            foodResults = new List<Food>();
            foodResults = foodDB.getAllFood();
            dogFoodTable.Columns.Add("Select Dog food");
            foreach (Food data in foodResults)
            {
                dogFoodTable.Rows.Add(data.FoodInfo);
            }
            dogFoodDGV.DataSource = dogFoodTable;

            clientResults = new List<Client>();
            clientResults = ClientDB.getAllClients();
            clientTable = new DataTable();
            clientTable.Columns.Add("Select Client");
            foreach (Client data in clientResults)
            {
                clientTable.Rows.Add(data.Clientname);
            }
            clientDGV.DataSource = clientTable;

            dogResults = new List<Dogs>();
            dogResults = DogDB.getAllDogsNames();
            dogTable = new DataTable();
            dogTable.Columns.Add("Select Dog (S)");
            foreach (Dogs data in dogResults)
            {
                dogTable.Rows.Add(data.Dogname);
            }
            dogDGV.DataSource = dogTable;

            
            ReLoad();
        }

        private void servicesCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!selectedDate)
            {
                updateCosts();
            }
            else
            {
                MessageBox.Show("Please select dates first", "ERROR");
            }
        }
        public void updateCosts()
        {

            selectedService = servicesResults[servicesCB.SelectedIndex].serviceId;
            int noOfMonthsBooked = bookingThing.BusinessDaysUntil(newBookingCal.SelectionStart, newBookingCal.SelectionStart);
            int noOfDaysBooked = (selectedEnd - selectedStart).Days;
            if (noOfMonthsBooked > 12)
            {
                discounts -= .1;
            }
            else if (noOfMonthsBooked > 6)
            {
                discounts -= .06;
            }
            else if (noOfMonthsBooked > 3)
            {
                discounts -= .03;
            }
            else
            {

            }
            runningCosts = noOfDaysBooked * servicesResults[servicesCB.SelectedIndex].cost * discounts;
            totalLBL.Text = "£" + String.Format("{0:0.00}", runningCosts);
        }
        
        public void ReLoad()
        {
            foreach (Control part in this.Controls)
            {
                string test;
                try
                {
                    test = part.Tag.ToString();
                }
                catch
                {
                    test = "";
                }
                switch (test)
                {
                    case ("NoneGrayable"):
                        part.Visible = true;
                        break;
                    case ("newDog"):
                        part.Visible = newDogBTN.Checked;
                        break;
                    case ("excistingDog"):
                        part.Visible = excsitingBTN.Checked;
                        break;
                    case ("newClient"):
                        part.Visible = NewClientBTN.Checked;
                        break;
                    case ("excistingCustomers"):
                        part.Visible = excistingClientBTN.Checked;
                        break;
                    default:
                        part.Visible = false;
                        break;
                }
                switch (part.Name)
                {
                    case ("dogNameTXT"):
                        part.Visible = newDogBTN.Checked;
                        break;
                    case ("nameLineOne"):
                        part.Visible = NewClientBTN.Checked;
                        break;
                    case ("addressLineOne"):
                        part.Visible = NewClientBTN.Checked;
                        break;
                    case ("addressLineTwo"):
                        part.Visible = NewClientBTN.Checked;
                        break;
                    case ("PostCodeLine"):
                        part.Visible = NewClientBTN.Checked;
                        break;
                    default:
                        break;
                }
            }
        }

        private void MonthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (!selectedDate)
            {
                newBookingCal.BoldedDates = new DateTime[] { };
                if (bookingThing.BusinessDaysUntil(newBookingCal.SelectionStart, newBookingCal.SelectionStart) > 0)
                {

                    selectedStart = newBookingCal.SelectionStart;
                    selectedDate = true;
                    newBookingCal.MinDate = selectedStart;
                }
            }
            else
            {
                if (selectedStart > newBookingCal.SelectionEnd)
                {

                }
                else
                {
                    if (bookingThing.BusinessDaysUntil(newBookingCal.SelectionStart, newBookingCal.SelectionStart) > 0)
                    {
                        selectedEnd = newBookingCal.SelectionStart;
                        int bankHolidayFree = bookingThing.BusinessDaysUntil(selectedStart, newBookingCal.SelectionStart);
                        newBookingCal.BoldedDates = bookingThing.highLightDays(selectedStart, bankHolidayFree).ToArray();
                        selectedDate = false;
                        newBookingCal.MinDate = new DateTime(2018, 01, 01);
                        if (servicesCB.SelectedIndex > -1)
                        {
                            updateCosts();
                        }
                    }
                }
            }
        }
        public void validateInput(Control part)
        {
            if (newDogBTN.Checked == true && part.Name == "dogNameTXT")
            {
                try
                {
                    VALdogName = inputVal.valName(part.Text);
                }
                catch
                {
                    updateOutputVal("No dog value inputted ");
                }
            }
            if (NewClientBTN.Checked == true)
            {
                switch (part.Name)
                {
                    case ("nameLineOne"):
                        try
                        {
                            VALclientname = inputVal.valName(part.Text);
                        }
                        catch
                        {
                            updateOutputVal("No client name entered ");
                        }
                        if(VALclientname == "ERROR")
                        {
                            updateOutputVal("Client name contains an invalid case ");
                        }
                        break;
                    case ("addressLineOne"):
                        try
                        {
                            VALaddressLineOne = inputVal.valAdressLine(part.Text);
                        }
                        catch
                        {
                            updateOutputVal("No first address line entered ");
                        }
                        if (VALaddressLineOne == "ERROR")
                        {
                            updateOutputVal("First address contains an invalid case ");
                        }
                        break;
                    case ("addressLineTwo"):
                        try
                        {
                            VALaddressLineTwo = inputVal.valAdressLine(part.Text);
                        }
                        catch
                        {
                            updateOutputVal( "No second address line entered ");

                        }
                        if (VALaddressLineTwo == "ERROR")
                        {
                            updateOutputVal("Second address line entered contains an invalid case ");

                        }
                        break;
                    case ("PostCodeLine"):
                        try
                        {
                            VALpostcode = inputVal.valPostCode(part.Text);
                        }
                        catch
                        {
                            updateOutputVal( "No postcode entered ");
                        }
                        if (VALpostcode == "ERROR")
                        {
                            updateOutputVal("Postcode entered contains an invalid case ");
                        }
                        break;
                    default:

                        break;
                }
            }
        }
        private void SubmitBTN_Click(object sender, EventArgs e)
        {
            if (dogSelected == true && clientSelected == true && servicesCB.SelectedIndex > -1)
            {
                if (newDogBTN.Checked == true)
                {
                    noOfDogs = 1;
                }
                else
                {
                    noOfDogs = dogDGV.SelectedCells.Count;
                }

                if (!selectedDate && output == null)
                {
                    foreach (Control part in this.Controls)
                    {
                        try
                        {
                            validateInput(part);
                        }
                        catch (Exception pep)
                        {
                            MessageBox.Show(pep.Message);
                        }
                    }
                    if (VALdogName == "ERROR" || VALclientname == "ERROR" || VALaddressLineTwo == "ERROR" || VALaddressLineOne == "ERROR") errorCheck =true;
                    if (NewClientBTN.Checked == true && errorCheck!= true)
                    {
                        generateClient();
                    }
                    else
                    {
                        clientID = clientResults[clientDGV.CurrentCell.RowIndex].ClientID;
                        
                    }
                    if (newDogBTN.Checked == true && errorCheck != true)
                    {
                        generateDog();
                    }
                    else
                    {
                        if (errorCheck != true)
                        {
                            dogID = dogResults[dogDGV.CurrentCell.RowIndex].DogID;
                        }
                    }
                    if (!billingDB.getClientMissedPayments(clientID) && errorCheck != true)
                    {
                        billingDB.createFees(selectedService);
                        billingID = billingDB.getLatestFeesID();
                        generateBooking();

                    }
                    else
                    {
                        updateOutputVal("Error with inputs please ensure client has no missed payments and that all input is correct");
                    }
                }

            }
            else
            {
                updateOutputVal("Error, you haven't completed the form");
            }
            MessageBox.Show(output, "Addling clients submition");
            output = null;
        }
        public void updateOutputVal(string message)
        {
            //To ensure correct capitalisation, this algorythm was developed
            string lowerCase =char.ToLowerInvariant(message[0]) + message.Substring(1);
            if (output == "")
            {
                output = message;
            }
            else
            {
                output += lowerCase;
            }
        }

        public void generateClient()
        {
            if (ClientDB.checkForDuplicateEntery(VALclientname, VALaddressLineOne, VALaddressLineTwo, VALpostcode, paymentCB.Text) == false)
            {
                if (ClientDB.createClient(VALclientname, VALaddressLineOne, VALaddressLineTwo, VALpostcode, paymentCB.Text))
                {
                    clientID = ClientDB.getClientID(VALclientname, VALaddressLineOne);
                }
                else
                {
                    updateOutputVal("Error generating clients");
                }

            }
            else
            {
                clientID = ClientDB.getClientID(VALclientname, VALaddressLineOne);
                updateOutputVal("Client allready excsits");
            }

        }
        public void generateDog()
        {
            if(dogToOwnersDB.checkForDogIDLink(VALdogName, clientID) == false)
            {
                if (DogDB.createDog(VALdogName, dogFoodDGV.CurrentCell.RowIndex+1) == true)
                {
                    dogID = DogDB.getLatestDogID(VALdogName);
                    
                    for (int vacNum = 0; vacNum <vaccineDGV.Rows.Count; vacNum++)
                    {
                        if(vaccineDGV.Rows[vacNum].Selected == true && vacNum !=0) {
                            vaccinesDB.updateVTDTable(VaccinesResults[vacNum].VaccineID, dogID);
                        }
                    }
                }
                else
                {
                    updateOutputVal("Error in sql, contact the developer");
                }
            }
            else
            {
                updateOutputVal("Dog allready excists to this client");
            }
        }
        public void generateBooking()
        {
            if (!selectedDate)
            {
                if (dogToOwnersDB.getLinkForIDs(clientID, dogID) == false)
                {
                    dogToOwnersDB.createLink(clientID, dogID);
                }
                //generate link to billing]
                int serviceseID = servicesResults[ servicesCB.SelectedIndex].serviceId;
                billingDB.createFees(serviceseID);
                int billingID = billingDB.getLatestFeesID();
                if (bookingDB.createBooking(clientID, dogID, billingID, emergancyBTN.Checked, selectedStart, selectedEnd) == true)
                {
                    updateOutputVal("Booking sucess");
                }
                else
                {
                    updateOutputVal("Error generating booking");
                }
            }
        }




        private void cancleBTN_Click(object sender, EventArgs e)
        {

            this.Hide();
            var form2 = new booking();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }




            private void ExcsitingBTN_CheckedChanged(object sender, EventArgs e)
        {
            if ((excsitingBTN.Checked == false && newDogBTN.Checked == true) || (excsitingBTN.Checked == true && newDogBTN.Checked == false))
            {
                dogSelected = true;
            }
            else if(excsitingBTN.Checked == true && newDogBTN.Checked == true)
            {
                newDogBTN.Checked = !excsitingBTN.Checked;
                dogSelected = true;

            }
            else
            {
                dogSelected = excsitingBTN.Checked;
            }
            ReLoad();
        }

        private void NewDogBTN_CheckedChanged(object sender, EventArgs e)
        {
            if ((excsitingBTN.Checked == false && newDogBTN.Checked == true) || (excsitingBTN.Checked == true && newDogBTN.Checked == false))
            {
                dogSelected = true;
            }
            else if (excsitingBTN.Checked == true && newDogBTN.Checked == true)
            {
                excsitingBTN.Checked = !newDogBTN.Checked;
                dogSelected = true;

            }
            else
            {
                dogSelected = newDogBTN.Checked;
            }
            ReLoad();
        }

        private void ExcistingClientBTN_CheckedChanged(object sender, EventArgs e)
        {
            if ((excistingClientBTN.Checked == false && NewClientBTN.Checked == true) || (excistingClientBTN.Checked == true && NewClientBTN.Checked == false))
            {
                clientSelected = true;
            }
            else if (excistingClientBTN.Checked == true && NewClientBTN.Checked == true)
            {
                NewClientBTN.Checked = !excistingClientBTN.Checked;
                clientSelected = true;

            }
            else
            {
                clientSelected = excistingClientBTN.Checked;
            }
            ReLoad();
        }

        private void newClientBTN_CheckedChanged(object sender, EventArgs e)
        {

            if ((excistingClientBTN.Checked == false && NewClientBTN.Checked == true) || (excistingClientBTN.Checked == true && NewClientBTN.Checked == false))
            {
                clientSelected = true;
            }
            else if (excistingClientBTN.Checked == true && NewClientBTN.Checked == true)
            {
                excistingClientBTN.Checked = !NewClientBTN.Checked;
                clientSelected = true;

            }
            else
            {
                clientSelected = NewClientBTN.Checked;
            }
            ReLoad();
        }

    }
}
