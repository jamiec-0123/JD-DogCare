﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class addNewStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLBL = new System.Windows.Forms.TextBox();
            this.morningBTN = new System.Windows.Forms.CheckBox();
            this.MondayBTN = new System.Windows.Forms.CheckBox();
            this.afternoonBTN = new System.Windows.Forms.CheckBox();
            this.TuesdayBTN = new System.Windows.Forms.CheckBox();
            this.WendsdayBTN = new System.Windows.Forms.CheckBox();
            this.ThursdayBTN = new System.Windows.Forms.CheckBox();
            this.FridayBTN = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.daysPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timePanel = new System.Windows.Forms.Panel();
            this.daysPanel.SuspendLayout();
            this.timePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameLBL
            // 
            this.nameLBL.Location = new System.Drawing.Point(5, 66);
            this.nameLBL.Name = "nameLBL";
            this.nameLBL.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nameLBL.Size = new System.Drawing.Size(208, 20);
            this.nameLBL.TabIndex = 0;
            this.nameLBL.Text = "Enter Name";
            this.nameLBL.Click += new System.EventHandler(this.NameLBL_Click);
            // 
            // morningBTN
            // 
            this.morningBTN.AutoSize = true;
            this.morningBTN.Location = new System.Drawing.Point(0, 3);
            this.morningBTN.Name = "morningBTN";
            this.morningBTN.Size = new System.Drawing.Size(64, 17);
            this.morningBTN.TabIndex = 1;
            this.morningBTN.Text = "Morning";
            this.morningBTN.UseVisualStyleBackColor = true;
            // 
            // MondayBTN
            // 
            this.MondayBTN.AutoSize = true;
            this.MondayBTN.Location = new System.Drawing.Point(-1, 0);
            this.MondayBTN.Name = "MondayBTN";
            this.MondayBTN.Size = new System.Drawing.Size(64, 17);
            this.MondayBTN.TabIndex = 2;
            this.MondayBTN.Text = "Monday";
            this.MondayBTN.UseVisualStyleBackColor = true;
            // 
            // afternoonBTN
            // 
            this.afternoonBTN.AutoSize = true;
            this.afternoonBTN.Location = new System.Drawing.Point(70, 3);
            this.afternoonBTN.Name = "afternoonBTN";
            this.afternoonBTN.Size = new System.Drawing.Size(72, 17);
            this.afternoonBTN.TabIndex = 3;
            this.afternoonBTN.Text = "Afternoon";
            this.afternoonBTN.UseVisualStyleBackColor = true;
            // 
            // TuesdayBTN
            // 
            this.TuesdayBTN.AutoSize = true;
            this.TuesdayBTN.Location = new System.Drawing.Point(69, 0);
            this.TuesdayBTN.Name = "TuesdayBTN";
            this.TuesdayBTN.Size = new System.Drawing.Size(67, 17);
            this.TuesdayBTN.TabIndex = 4;
            this.TuesdayBTN.Text = "Tuesday";
            this.TuesdayBTN.UseVisualStyleBackColor = true;
            // 
            // WendsdayBTN
            // 
            this.WendsdayBTN.AutoSize = true;
            this.WendsdayBTN.Location = new System.Drawing.Point(142, 0);
            this.WendsdayBTN.Name = "WendsdayBTN";
            this.WendsdayBTN.Size = new System.Drawing.Size(77, 17);
            this.WendsdayBTN.TabIndex = 5;
            this.WendsdayBTN.Text = "Wendsday";
            this.WendsdayBTN.UseVisualStyleBackColor = true;
            // 
            // ThursdayBTN
            // 
            this.ThursdayBTN.AutoSize = true;
            this.ThursdayBTN.Location = new System.Drawing.Point(225, 0);
            this.ThursdayBTN.Name = "ThursdayBTN";
            this.ThursdayBTN.Size = new System.Drawing.Size(70, 17);
            this.ThursdayBTN.TabIndex = 6;
            this.ThursdayBTN.Text = "Thursday";
            this.ThursdayBTN.UseVisualStyleBackColor = true;
            // 
            // FridayBTN
            // 
            this.FridayBTN.AutoSize = true;
            this.FridayBTN.Location = new System.Drawing.Point(301, 0);
            this.FridayBTN.Name = "FridayBTN";
            this.FridayBTN.Size = new System.Drawing.Size(54, 17);
            this.FridayBTN.TabIndex = 7;
            this.FridayBTN.Text = "Friday";
            this.FridayBTN.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(286, 115);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.addStaff_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(5, 115);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // daysPanel
            // 
            this.daysPanel.Controls.Add(this.FridayBTN);
            this.daysPanel.Controls.Add(this.MondayBTN);
            this.daysPanel.Controls.Add(this.TuesdayBTN);
            this.daysPanel.Controls.Add(this.WendsdayBTN);
            this.daysPanel.Controls.Add(this.ThursdayBTN);
            this.daysPanel.Location = new System.Drawing.Point(5, 92);
            this.daysPanel.Name = "daysPanel";
            this.daysPanel.Size = new System.Drawing.Size(356, 17);
            this.daysPanel.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(257, -38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(104, 23);
            this.panel1.TabIndex = 11;
            // 
            // timePanel
            // 
            this.timePanel.Controls.Add(this.morningBTN);
            this.timePanel.Controls.Add(this.afternoonBTN);
            this.timePanel.Location = new System.Drawing.Point(219, 66);
            this.timePanel.Name = "timePanel";
            this.timePanel.Size = new System.Drawing.Size(141, 20);
            this.timePanel.TabIndex = 12;
            // 
            // addNewStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 141);
            this.Controls.Add(this.timePanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.daysPanel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nameLBL);
            this.Name = "addNewStaff";
            this.Text = "Add Staff";
            this.daysPanel.ResumeLayout(false);
            this.daysPanel.PerformLayout();
            this.timePanel.ResumeLayout(false);
            this.timePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameLBL;
        private System.Windows.Forms.CheckBox morningBTN;
        private System.Windows.Forms.CheckBox MondayBTN;
        private System.Windows.Forms.CheckBox afternoonBTN;
        private System.Windows.Forms.CheckBox TuesdayBTN;
        private System.Windows.Forms.CheckBox WendsdayBTN;
        private System.Windows.Forms.CheckBox ThursdayBTN;
        private System.Windows.Forms.CheckBox FridayBTN;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel daysPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel timePanel;
    }
}