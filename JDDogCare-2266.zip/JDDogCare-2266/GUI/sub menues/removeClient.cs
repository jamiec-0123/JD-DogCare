﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;
namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class removeClient : Form
    {
        List<Tuple<Dogs, Client, Booking,Billing>> booking;
        bookingDBAccess BookingDB;
        DogDBAcess DogDB;
        ClientDBAccess ClientDB;
        dogToOwnersDBAcess dogToOwnersDB;
        vaccinesToDogDBAccess VacinationToDogDB;
        public removeClient(List<Tuple<Dogs, Client, Booking,Billing>> booking, DataBase db)
        {
            this.booking = booking;
            BookingDB = new bookingDBAccess(db);
            DogDB = new DogDBAcess(db);
            ClientDB = new ClientDBAccess(db);
            dogToOwnersDB = new dogToOwnersDBAcess(db);
            VacinationToDogDB = new vaccinesToDogDBAccess(db);
            InitializeComponent();
        }

        private void CancelBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (clientRadio.Checked)
            {
                foreach (Tuple<Dogs, Client, Booking, Billing> data in booking)
                {
                    dogToOwnersDB.deleteBasedOnDogID(data.Item2.ClientID);
                    BookingDB.deleteBooking(data.Item3.BookingID);
                    dogToOwnersDB.deleteBasedOnClientID(data.Item2.ClientID);
                    ClientDB.deleteClient(data.Item2.ClientID);
                }
            }
            else if (dogRadio.Checked)
            {
                foreach (Tuple<Dogs, Client, Booking, Billing> data in booking)
                {
                    VacinationToDogDB.deleteDog(data.Item1.DogID);
                    BookingDB.deleteBooking(data.Item3.BookingID);
                    dogToOwnersDB.deleteBasedOnDogID(data.Item1.DogID);
                    DogDB.deleteDog(data.Item1.DogID);
                }
            }
            else if (bookingRadio.Checked)
            {
                foreach (Tuple<Dogs, Client, Booking,Billing> data in booking)
                {
                    BookingDB.deleteBooking(data.Item3.BookingID);
                }

            }
            else
            {
                MessageBox.Show("You have not selected an option");
            }
            MessageBox.Show("Success", "Removed");
            this.Close();
        }
    }
}
