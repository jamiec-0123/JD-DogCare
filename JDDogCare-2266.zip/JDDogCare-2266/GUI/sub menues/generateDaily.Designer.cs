﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class generateDaily
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.staffOnDuty = new System.Windows.Forms.DataGridView();
            this.dayCareSheet = new System.Windows.Forms.DataGridView();
            this.dogsSheet = new System.Windows.Forms.DataGridView();
            this.updateSelectionBTN = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.removeLinkBTN = new System.Windows.Forms.Button();
            this.servicesCB = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.saveBTN = new System.Windows.Forms.Button();
            this.cancelBTN = new System.Windows.Forms.Button();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.staffOnDuty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dayCareSheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogsSheet)).BeginInit();
            this.SuspendLayout();
            // 
            // staffOnDuty
            // 
            this.staffOnDuty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffOnDuty.Location = new System.Drawing.Point(12, 100);
            this.staffOnDuty.Name = "staffOnDuty";
            this.staffOnDuty.Size = new System.Drawing.Size(349, 237);
            this.staffOnDuty.TabIndex = 0;
            // 
            // dayCareSheet
            // 
            this.dayCareSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dayCareSheet.Location = new System.Drawing.Point(448, 100);
            this.dayCareSheet.Name = "dayCareSheet";
            this.dayCareSheet.Size = new System.Drawing.Size(325, 443);
            this.dayCareSheet.TabIndex = 1;
            // 
            // dogsSheet
            // 
            this.dogsSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dogsSheet.Location = new System.Drawing.Point(12, 377);
            this.dogsSheet.Name = "dogsSheet";
            this.dogsSheet.Size = new System.Drawing.Size(349, 237);
            this.dogsSheet.TabIndex = 2;
            // 
            // updateSelectionBTN
            // 
            this.updateSelectionBTN.Location = new System.Drawing.Point(367, 332);
            this.updateSelectionBTN.Name = "updateSelectionBTN";
            this.updateSelectionBTN.Size = new System.Drawing.Size(75, 23);
            this.updateSelectionBTN.TabIndex = 3;
            this.updateSelectionBTN.Text = "Add";
            this.updateSelectionBTN.UseVisualStyleBackColor = true;
            this.updateSelectionBTN.Click += new System.EventHandler(this.UpdateSelectionBTN_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Staff On Duty";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 354);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Dogs Booked In";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(448, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Day care sheet";
            // 
            // removeLinkBTN
            // 
            this.removeLinkBTN.Location = new System.Drawing.Point(367, 361);
            this.removeLinkBTN.Name = "removeLinkBTN";
            this.removeLinkBTN.Size = new System.Drawing.Size(75, 23);
            this.removeLinkBTN.TabIndex = 9;
            this.removeLinkBTN.Text = "Remove";
            this.removeLinkBTN.UseVisualStyleBackColor = true;
            this.removeLinkBTN.Click += new System.EventHandler(this.RemoveLinkBTN_Click);
            // 
            // servicesCB
            // 
            this.servicesCB.FormattingEnabled = true;
            this.servicesCB.Location = new System.Drawing.Point(666, 77);
            this.servicesCB.Name = "servicesCB";
            this.servicesCB.Size = new System.Drawing.Size(107, 21);
            this.servicesCB.TabIndex = 10;
            this.servicesCB.Tag = "NoneGrayable";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(586, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Select by staff";
            // 
            // saveBTN
            // 
            this.saveBTN.Location = new System.Drawing.Point(698, 549);
            this.saveBTN.Name = "saveBTN";
            this.saveBTN.Size = new System.Drawing.Size(75, 23);
            this.saveBTN.TabIndex = 13;
            this.saveBTN.Text = "Save";
            this.saveBTN.UseVisualStyleBackColor = true;
            this.saveBTN.Click += new System.EventHandler(this.SaveBTN_Click);
            // 
            // cancelBTN
            // 
            this.cancelBTN.Location = new System.Drawing.Point(698, 578);
            this.cancelBTN.Name = "cancelBTN";
            this.cancelBTN.Size = new System.Drawing.Size(75, 23);
            this.cancelBTN.TabIndex = 14;
            this.cancelBTN.Text = "Cancel ";
            this.cancelBTN.UseVisualStyleBackColor = true;
            this.cancelBTN.Click += new System.EventHandler(this.CancelBTN_Click);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(161, 74);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker.TabIndex = 8;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.DateTimePicker_ValueChanged);
            // 
            // generateDaily
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 620);
            this.Controls.Add(this.cancelBTN);
            this.Controls.Add(this.saveBTN);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.servicesCB);
            this.Controls.Add(this.removeLinkBTN);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.updateSelectionBTN);
            this.Controls.Add(this.dogsSheet);
            this.Controls.Add(this.dayCareSheet);
            this.Controls.Add(this.staffOnDuty);
            this.Name = "generateDaily";
            this.Text = "Customise day care sheet";
            this.Load += new System.EventHandler(this.generateDaily_Load);
            ((System.ComponentModel.ISupportInitialize)(this.staffOnDuty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dayCareSheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogsSheet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView staffOnDuty;
        private System.Windows.Forms.DataGridView dayCareSheet;
        private System.Windows.Forms.DataGridView dogsSheet;
        private System.Windows.Forms.Button updateSelectionBTN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button removeLinkBTN;
        private System.Windows.Forms.ComboBox servicesCB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button saveBTN;
        private System.Windows.Forms.Button cancelBTN;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
    }
}