﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using JDDogCare_2266.DBAccess;
using System.Threading;

namespace JDDogCare_2266.GUI.sub_menues
{
    public partial class addIncident : MaterialSkin.Controls.MaterialForm
    {
        DogDBAcess DogDB;
        RepercussionsBDAcess RepercussionsDB;
        List<Dogs> DogsDBData;
        List<Repercussions> reprecussionsData;
        incidentDBAccess incidentDB;
        textValidation validation;
        DataBase db;

        DateTime selectedDate;
        public addIncident(int dogID, DateTime dateOfIncident, DataBase db)
        {
            selectedDate = dateOfIncident;
            this.db = db;
            InitializeComponent();
        }
        public addIncident(DateTime dateOfIncident, DataBase db)
        {
            selectedDate = dateOfIncident;
            this.db = db;
            InitializeComponent();
        }

        private void addIncident_Load(object sender, EventArgs e)
        {
            validation = new textValidation();
            incidentDB = new incidentDBAccess(db);
            DogDB = new DogDBAcess(db);
            RepercussionsDB = new RepercussionsBDAcess(db);
            DogsDBData = new List<Dogs>();
            reprecussionsData = new List<Repercussions>();
            validation = new textValidation();
            DogsDBData = DogDB.getAllDogsNames();
            reprecussionsData = RepercussionsDB.getAll();
            foreach (Dogs data in DogsDBData)
            {
                dogsCB.Items.Add(data.Dogname + " ID:" + data.DogID.ToString());
            }
            foreach (Repercussions data in reprecussionsData)
            {
                if (data.Cost != 0)
                {
                    repercussionCB.Items.Add("Cost increase by" + data.Cost);
                }
                else
                {
                    repercussionCB.Items.Add("Ban");
                }
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void clientMenuStart()
        {
            Application.Run(new booking());
        }

        private void updateBTN_Click(object sender, EventArgs e)
        {
            if(issueTXT.Text == "")
            {
                MessageBox.Show("No details on incident, please provide some amount of information", "ERROR");
            }
            else
            {
                if(dogsCB.SelectedIndex == -1 || repercussionCB.SelectedIndex == -1)
                {
                    MessageBox.Show("No options selected", "ERROR");

                }
                else
                {
                    //public bool generateIncident( int dogID, int repercussionsID,string info, DateTime dateOfIncident)
                    var test = validation.valAdressLine(issueTXT.Text);
                    incidentDB.generateIncident(DogsDBData[dogsCB.SelectedIndex].DogID, reprecussionsData[repercussionCB.SelectedIndex].ReprecussionsID, test, selectedDate);
                    MessageBox.Show("Incident Recorded", "Sucssess");
                    this.Close();
                }
            }
        }
    }
}
