﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class addBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addBooking));
            this.startLBL = new MaterialSkin.Controls.MaterialLabel();
            this.newBookingCal = new System.Windows.Forms.MonthCalendar();
            this.twothirdBreaker = new MaterialSkin.Controls.MaterialDivider();
            this.dogNameLBL = new MaterialSkin.Controls.MaterialLabel();
            this.servicesLBL = new MaterialSkin.Controls.MaterialLabel();
            this.servicesCB = new System.Windows.Forms.ComboBox();
            this.emergancyBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.newDogBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.dogNameTXT = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.vaccineLBL = new MaterialSkin.Controls.MaterialLabel();
            this.onethirdBreaker = new MaterialSkin.Controls.MaterialDivider();
            this.excsitingBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.selectLBL = new MaterialSkin.Controls.MaterialLabel();
            this.topBreaker = new MaterialSkin.Controls.MaterialDivider();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.totalLBL = new MaterialSkin.Controls.MaterialLabel();
            this.vaccineDGV = new System.Windows.Forms.DataGridView();
            this.dogFoodDGV = new System.Windows.Forms.DataGridView();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.clientDGV = new System.Windows.Forms.DataGridView();
            this.addressLineOne = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.nameLineOne = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.addressLineTwo = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.excistingClientBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.NewClientBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.cancleBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.submitBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.PostCodeLine = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.paymentCB = new System.Windows.Forms.ComboBox();
            this.thirdBreaker = new MaterialSkin.Controls.MaterialDivider();
            this.paymentLBL = new MaterialSkin.Controls.MaterialLabel();
            this.PostcodeLBL = new MaterialSkin.Controls.MaterialLabel();
            this.AddressTwoLBL = new MaterialSkin.Controls.MaterialLabel();
            this.addressOneLBL = new MaterialSkin.Controls.MaterialLabel();
            this.nameLBL = new MaterialSkin.Controls.MaterialLabel();
            this.dogDGV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.vaccineDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogFoodDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // startLBL
            // 
            this.startLBL.AutoSize = true;
            this.startLBL.Depth = 0;
            this.startLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.startLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.startLBL.Location = new System.Drawing.Point(63, 83);
            this.startLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.startLBL.Name = "startLBL";
            this.startLBL.Size = new System.Drawing.Size(135, 23);
            this.startLBL.TabIndex = 0;
            this.startLBL.Tag = "NoneGrayable";
            this.startLBL.Text = "Select booking dates";
            // 
            // newBookingCal
            // 
            this.newBookingCal.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            this.newBookingCal.Location = new System.Drawing.Point(-7, 115);
            this.newBookingCal.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.newBookingCal.Name = "newBookingCal";
            this.newBookingCal.TabIndex = 0;
            this.newBookingCal.Tag = "NoneGrayable";
            this.newBookingCal.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateSelected);
            // 
            // twothirdBreaker
            // 
            this.twothirdBreaker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.twothirdBreaker.Depth = 0;
            this.twothirdBreaker.Location = new System.Drawing.Point(526, 62);
            this.twothirdBreaker.MouseState = MaterialSkin.MouseState.Hover;
            this.twothirdBreaker.Name = "twothirdBreaker";
            this.twothirdBreaker.Size = new System.Drawing.Size(10, 564);
            this.twothirdBreaker.TabIndex = 19;
            this.twothirdBreaker.Tag = "NoneGrayable";
            this.twothirdBreaker.Text = "materialDivider2";
            // 
            // dogNameLBL
            // 
            this.dogNameLBL.AutoSize = true;
            this.dogNameLBL.Depth = 0;
            this.dogNameLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.dogNameLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dogNameLBL.Location = new System.Drawing.Point(240, 110);
            this.dogNameLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.dogNameLBL.Name = "dogNameLBL";
            this.dogNameLBL.Size = new System.Drawing.Size(79, 23);
            this.dogNameLBL.TabIndex = 25;
            this.dogNameLBL.Tag = "newDog";
            this.dogNameLBL.Text = "Dogs Name";
            // 
            // servicesLBL
            // 
            this.servicesLBL.AutoSize = true;
            this.servicesLBL.Depth = 0;
            this.servicesLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.servicesLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.servicesLBL.Location = new System.Drawing.Point(12, 286);
            this.servicesLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.servicesLBL.Name = "servicesLBL";
            this.servicesLBL.Size = new System.Drawing.Size(108, 23);
            this.servicesLBL.TabIndex = 0;
            this.servicesLBL.Tag = "NoneGrayable";
            this.servicesLBL.Text = "services options";
            // 
            // servicesCB
            // 
            this.servicesCB.FormattingEnabled = true;
            this.servicesCB.Location = new System.Drawing.Point(12, 314);
            this.servicesCB.Name = "servicesCB";
            this.servicesCB.Size = new System.Drawing.Size(186, 21);
            this.servicesCB.TabIndex = 1;
            this.servicesCB.Tag = "NoneGrayable";
            this.servicesCB.SelectedIndexChanged += new System.EventHandler(this.servicesCB_SelectedIndexChanged);
            // 
            // emergancyBTN
            // 
            this.emergancyBTN.AutoSize = true;
            this.emergancyBTN.Depth = 0;
            this.emergancyBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.emergancyBTN.Location = new System.Drawing.Point(12, 340);
            this.emergancyBTN.Margin = new System.Windows.Forms.Padding(0);
            this.emergancyBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.emergancyBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.emergancyBTN.Name = "emergancyBTN";
            this.emergancyBTN.Ripple = true;
            this.emergancyBTN.Size = new System.Drawing.Size(133, 30);
            this.emergancyBTN.TabIndex = 2;
            this.emergancyBTN.Tag = "NoneGrayable";
            this.emergancyBTN.Text = "Emergancy Care";
            this.emergancyBTN.UseVisualStyleBackColor = true;
            // 
            // newDogBTN
            // 
            this.newDogBTN.AutoSize = true;
            this.newDogBTN.Depth = 0;
            this.newDogBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.newDogBTN.Location = new System.Drawing.Point(240, 78);
            this.newDogBTN.Margin = new System.Windows.Forms.Padding(0);
            this.newDogBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.newDogBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.newDogBTN.Name = "newDogBTN";
            this.newDogBTN.Ripple = true;
            this.newDogBTN.Size = new System.Drawing.Size(85, 30);
            this.newDogBTN.TabIndex = 3;
            this.newDogBTN.Tag = "NoneGrayable";
            this.newDogBTN.Text = "New dog";
            this.newDogBTN.UseVisualStyleBackColor = true;
            this.newDogBTN.CheckedChanged += new System.EventHandler(this.NewDogBTN_CheckedChanged);
            // 
            // dogNameTXT
            // 
            this.dogNameTXT.Depth = 0;
            this.dogNameTXT.EnterToTab = false;
            this.dogNameTXT.Hint = "";
            this.dogNameTXT.Location = new System.Drawing.Point(240, 136);
            this.dogNameTXT.MaxLength = 32767;
            this.dogNameTXT.MouseState = MaterialSkin.MouseState.Hover;
            this.dogNameTXT.Name = "dogNameTXT";
            this.dogNameTXT.PasswordChar = '\0';
            this.dogNameTXT.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dogNameTXT.SelectedText = "";
            this.dogNameTXT.SelectionLength = 0;
            this.dogNameTXT.SelectionStart = 0;
            this.dogNameTXT.Size = new System.Drawing.Size(280, 30);
            this.dogNameTXT.TabIndex = 35;
            this.dogNameTXT.TabStop = false;
            this.dogNameTXT.Tag = "newDog";
            this.dogNameTXT.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.dogNameTXT.UseSystemPasswordChar = false;
            // 
            // vaccineLBL
            // 
            this.vaccineLBL.AutoSize = true;
            this.vaccineLBL.Depth = 0;
            this.vaccineLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.vaccineLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.vaccineLBL.Location = new System.Drawing.Point(240, 381);
            this.vaccineLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.vaccineLBL.Name = "vaccineLBL";
            this.vaccineLBL.Size = new System.Drawing.Size(63, 23);
            this.vaccineLBL.TabIndex = 37;
            this.vaccineLBL.Tag = "newDog";
            this.vaccineLBL.Text = "Vaccines";
            // 
            // onethirdBreaker
            // 
            this.onethirdBreaker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.onethirdBreaker.Depth = 0;
            this.onethirdBreaker.Location = new System.Drawing.Point(225, 66);
            this.onethirdBreaker.MouseState = MaterialSkin.MouseState.Hover;
            this.onethirdBreaker.Name = "onethirdBreaker";
            this.onethirdBreaker.Size = new System.Drawing.Size(10, 564);
            this.onethirdBreaker.TabIndex = 39;
            this.onethirdBreaker.Tag = "NoneGrayable";
            this.onethirdBreaker.Text = "materialDivider3";
            // 
            // excsitingBTN
            // 
            this.excsitingBTN.AutoSize = true;
            this.excsitingBTN.Depth = 0;
            this.excsitingBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.excsitingBTN.Location = new System.Drawing.Point(407, 78);
            this.excsitingBTN.Margin = new System.Windows.Forms.Padding(0);
            this.excsitingBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.excsitingBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.excsitingBTN.Name = "excsitingBTN";
            this.excsitingBTN.Ripple = true;
            this.excsitingBTN.Size = new System.Drawing.Size(113, 30);
            this.excsitingBTN.TabIndex = 4;
            this.excsitingBTN.Tag = "NoneGrayable";
            this.excsitingBTN.Text = "Excisting dog";
            this.excsitingBTN.UseVisualStyleBackColor = true;
            this.excsitingBTN.CheckedChanged += new System.EventHandler(this.ExcsitingBTN_CheckedChanged);
            // 
            // selectLBL
            // 
            this.selectLBL.AutoSize = true;
            this.selectLBL.Depth = 0;
            this.selectLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.selectLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.selectLBL.Location = new System.Drawing.Point(240, 110);
            this.selectLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.selectLBL.Name = "selectLBL";
            this.selectLBL.Size = new System.Drawing.Size(87, 23);
            this.selectLBL.TabIndex = 49;
            this.selectLBL.Tag = "excistingDog";
            this.selectLBL.Text = "Select dog(s)";
            // 
            // topBreaker
            // 
            this.topBreaker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.topBreaker.Depth = 0;
            this.topBreaker.Location = new System.Drawing.Point(3, 62);
            this.topBreaker.MouseState = MaterialSkin.MouseState.Hover;
            this.topBreaker.Name = "topBreaker";
            this.topBreaker.Size = new System.Drawing.Size(1390, 10);
            this.topBreaker.TabIndex = 0;
            this.topBreaker.Tag = "NoneGrayable";
            this.topBreaker.Text = "materialDivider5";
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(238, 169);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(189, 23);
            this.materialLabel1.TabIndex = 52;
            this.materialLabel1.Text = "Select dog diatry requirments";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(12, 571);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(92, 23);
            this.materialLabel2.TabIndex = 0;
            this.materialLabel2.Tag = "NoneGrayable";
            this.materialLabel2.Text = "Running Cost";
            // 
            // totalLBL
            // 
            this.totalLBL.AutoSize = true;
            this.totalLBL.Depth = 0;
            this.totalLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.totalLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.totalLBL.Location = new System.Drawing.Point(11, 594);
            this.totalLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.totalLBL.Name = "totalLBL";
            this.totalLBL.Size = new System.Drawing.Size(36, 23);
            this.totalLBL.TabIndex = 0;
            this.totalLBL.Tag = "NoneGrayable";
            this.totalLBL.Text = "£0.00";
            // 
            // vaccineDGV
            // 
            this.vaccineDGV.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.vaccineDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vaccineDGV.ColumnHeadersVisible = false;
            this.vaccineDGV.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.vaccineDGV.Location = new System.Drawing.Point(240, 407);
            this.vaccineDGV.Name = "vaccineDGV";
            this.vaccineDGV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.vaccineDGV.Size = new System.Drawing.Size(280, 201);
            this.vaccineDGV.TabIndex = 57;
            this.vaccineDGV.Tag = "newDog";
            // 
            // dogFoodDGV
            // 
            this.dogFoodDGV.AllowUserToAddRows = false;
            this.dogFoodDGV.AllowUserToDeleteRows = false;
            this.dogFoodDGV.AllowUserToResizeColumns = false;
            this.dogFoodDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dogFoodDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dogFoodDGV.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dogFoodDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dogFoodDGV.GridColor = System.Drawing.SystemColors.Control;
            this.dogFoodDGV.Location = new System.Drawing.Point(240, 200);
            this.dogFoodDGV.MultiSelect = false;
            this.dogFoodDGV.Name = "dogFoodDGV";
            this.dogFoodDGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dogFoodDGV.Size = new System.Drawing.Size(280, 170);
            this.dogFoodDGV.TabIndex = 58;
            this.dogFoodDGV.Tag = "newDog";
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(544, 110);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(107, 23);
            this.materialLabel4.TabIndex = 95;
            this.materialLabel4.Tag = "excistingCustomers";
            this.materialLabel4.Text = "Select Customer";
            // 
            // clientDGV
            // 
            this.clientDGV.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.clientDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientDGV.Location = new System.Drawing.Point(543, 136);
            this.clientDGV.Name = "clientDGV";
            this.clientDGV.Size = new System.Drawing.Size(268, 440);
            this.clientDGV.TabIndex = 94;
            this.clientDGV.Tag = "excistingCustomers";
            // 
            // addressLineOne
            // 
            this.addressLineOne.Depth = 0;
            this.addressLineOne.EnterToTab = false;
            this.addressLineOne.Hint = "";
            this.addressLineOne.Location = new System.Drawing.Point(540, 206);
            this.addressLineOne.MaxLength = 32767;
            this.addressLineOne.MouseState = MaterialSkin.MouseState.Hover;
            this.addressLineOne.Name = "addressLineOne";
            this.addressLineOne.PasswordChar = '\0';
            this.addressLineOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addressLineOne.SelectedText = "";
            this.addressLineOne.SelectionLength = 0;
            this.addressLineOne.SelectionStart = 0;
            this.addressLineOne.Size = new System.Drawing.Size(268, 30);
            this.addressLineOne.TabIndex = 93;
            this.addressLineOne.TabStop = false;
            this.addressLineOne.Tag = "newClient";
            this.addressLineOne.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.addressLineOne.UseSystemPasswordChar = false;
            // 
            // nameLineOne
            // 
            this.nameLineOne.Depth = 0;
            this.nameLineOne.EnterToTab = false;
            this.nameLineOne.Hint = "";
            this.nameLineOne.Location = new System.Drawing.Point(543, 147);
            this.nameLineOne.MaxLength = 32767;
            this.nameLineOne.MouseState = MaterialSkin.MouseState.Hover;
            this.nameLineOne.Name = "nameLineOne";
            this.nameLineOne.PasswordChar = '\0';
            this.nameLineOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nameLineOne.SelectedText = "";
            this.nameLineOne.SelectionLength = 0;
            this.nameLineOne.SelectionStart = 0;
            this.nameLineOne.Size = new System.Drawing.Size(268, 30);
            this.nameLineOne.TabIndex = 92;
            this.nameLineOne.TabStop = false;
            this.nameLineOne.Tag = "newClient";
            this.nameLineOne.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.nameLineOne.UseSystemPasswordChar = false;
            // 
            // addressLineTwo
            // 
            this.addressLineTwo.Depth = 0;
            this.addressLineTwo.EnterToTab = false;
            this.addressLineTwo.Hint = "";
            this.addressLineTwo.Location = new System.Drawing.Point(543, 265);
            this.addressLineTwo.MaxLength = 32767;
            this.addressLineTwo.MouseState = MaterialSkin.MouseState.Hover;
            this.addressLineTwo.Name = "addressLineTwo";
            this.addressLineTwo.PasswordChar = '\0';
            this.addressLineTwo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addressLineTwo.SelectedText = "";
            this.addressLineTwo.SelectionLength = 0;
            this.addressLineTwo.SelectionStart = 0;
            this.addressLineTwo.Size = new System.Drawing.Size(268, 30);
            this.addressLineTwo.TabIndex = 91;
            this.addressLineTwo.TabStop = false;
            this.addressLineTwo.Tag = "newClient";
            this.addressLineTwo.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.addressLineTwo.UseSystemPasswordChar = false;
            // 
            // excistingClientBTN
            // 
            this.excistingClientBTN.AutoSize = true;
            this.excistingClientBTN.Depth = 0;
            this.excistingClientBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.excistingClientBTN.Location = new System.Drawing.Point(669, 78);
            this.excistingClientBTN.Margin = new System.Windows.Forms.Padding(0);
            this.excistingClientBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.excistingClientBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.excistingClientBTN.Name = "excistingClientBTN";
            this.excistingClientBTN.Ripple = true;
            this.excistingClientBTN.Size = new System.Drawing.Size(142, 30);
            this.excistingClientBTN.TabIndex = 86;
            this.excistingClientBTN.Tag = "NoneGrayable";
            this.excistingClientBTN.Text = "Excisting Client(s)";
            this.excistingClientBTN.UseVisualStyleBackColor = true;
            this.excistingClientBTN.CheckedChanged += new System.EventHandler(this.ExcistingClientBTN_CheckedChanged);
            // 
            // NewClientBTN
            // 
            this.NewClientBTN.AutoSize = true;
            this.NewClientBTN.Depth = 0;
            this.NewClientBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.NewClientBTN.Location = new System.Drawing.Point(540, 78);
            this.NewClientBTN.Margin = new System.Windows.Forms.Padding(0);
            this.NewClientBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.NewClientBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.NewClientBTN.Name = "NewClientBTN";
            this.NewClientBTN.Ripple = true;
            this.NewClientBTN.Size = new System.Drawing.Size(98, 30);
            this.NewClientBTN.TabIndex = 84;
            this.NewClientBTN.Tag = "NoneGrayable";
            this.NewClientBTN.Text = "New Client";
            this.NewClientBTN.UseVisualStyleBackColor = true;
            this.NewClientBTN.CheckedChanged += new System.EventHandler(this.newClientBTN_CheckedChanged);
            // 
            // cancleBTN
            // 
            this.cancleBTN.AutoSize = true;
            this.cancleBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.cancleBTN.Depth = 0;
            this.cancleBTN.Icon = null;
            this.cancleBTN.Location = new System.Drawing.Point(544, 585);
            this.cancleBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.cancleBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.cancleBTN.Name = "cancleBTN";
            this.cancleBTN.Primary = false;
            this.cancleBTN.Size = new System.Drawing.Size(74, 36);
            this.cancleBTN.TabIndex = 90;
            this.cancleBTN.Tag = "NoneGrayable";
            this.cancleBTN.Text = "Cancel";
            this.cancleBTN.UseVisualStyleBackColor = true;
            this.cancleBTN.Click += new System.EventHandler(this.cancleBTN_Click);
            // 
            // submitBTN
            // 
            this.submitBTN.AutoSize = true;
            this.submitBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.submitBTN.Depth = 0;
            this.submitBTN.Icon = null;
            this.submitBTN.Location = new System.Drawing.Point(738, 581);
            this.submitBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.submitBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.submitBTN.Name = "submitBTN";
            this.submitBTN.Primary = false;
            this.submitBTN.Size = new System.Drawing.Size(73, 36);
            this.submitBTN.TabIndex = 89;
            this.submitBTN.Tag = "NoneGrayable";
            this.submitBTN.Text = "SUBMIT";
            this.submitBTN.UseVisualStyleBackColor = true;
            this.submitBTN.Click += new System.EventHandler(this.SubmitBTN_Click);
            // 
            // PostCodeLine
            // 
            this.PostCodeLine.Depth = 0;
            this.PostCodeLine.EnterToTab = false;
            this.PostCodeLine.Hint = "";
            this.PostCodeLine.Location = new System.Drawing.Point(543, 324);
            this.PostCodeLine.MaxLength = 32767;
            this.PostCodeLine.MouseState = MaterialSkin.MouseState.Hover;
            this.PostCodeLine.Name = "PostCodeLine";
            this.PostCodeLine.PasswordChar = '\0';
            this.PostCodeLine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PostCodeLine.SelectedText = "";
            this.PostCodeLine.SelectionLength = 0;
            this.PostCodeLine.SelectionStart = 0;
            this.PostCodeLine.Size = new System.Drawing.Size(268, 30);
            this.PostCodeLine.TabIndex = 88;
            this.PostCodeLine.TabStop = false;
            this.PostCodeLine.Tag = "newClient";
            this.PostCodeLine.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.PostCodeLine.UseSystemPasswordChar = false;
            // 
            // paymentCB
            // 
            this.paymentCB.FormattingEnabled = true;
            this.paymentCB.Items.AddRange(new object[] {
            "Cash",
            "Cheques",
            "Debit Care",
            "Credit Card",
            "Standing Order"});
            this.paymentCB.Location = new System.Drawing.Point(544, 383);
            this.paymentCB.Name = "paymentCB";
            this.paymentCB.Size = new System.Drawing.Size(121, 21);
            this.paymentCB.TabIndex = 87;
            this.paymentCB.Tag = "newClient";
            // 
            // thirdBreaker
            // 
            this.thirdBreaker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.thirdBreaker.Depth = 0;
            this.thirdBreaker.Location = new System.Drawing.Point(820, 71);
            this.thirdBreaker.MouseState = MaterialSkin.MouseState.Hover;
            this.thirdBreaker.Name = "thirdBreaker";
            this.thirdBreaker.Size = new System.Drawing.Size(10, 583);
            this.thirdBreaker.TabIndex = 85;
            this.thirdBreaker.Tag = "NoneGrayable";
            this.thirdBreaker.Text = "materialDivider1";
            // 
            // paymentLBL
            // 
            this.paymentLBL.AutoSize = true;
            this.paymentLBL.Depth = 0;
            this.paymentLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.paymentLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.paymentLBL.Location = new System.Drawing.Point(544, 357);
            this.paymentLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.paymentLBL.Name = "paymentLBL";
            this.paymentLBL.Size = new System.Drawing.Size(96, 23);
            this.paymentLBL.TabIndex = 83;
            this.paymentLBL.Tag = "newClient";
            this.paymentLBL.Text = "Payment Type";
            // 
            // PostcodeLBL
            // 
            this.PostcodeLBL.AutoSize = true;
            this.PostcodeLBL.Depth = 0;
            this.PostcodeLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.PostcodeLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PostcodeLBL.Location = new System.Drawing.Point(544, 298);
            this.PostcodeLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.PostcodeLBL.Name = "PostcodeLBL";
            this.PostcodeLBL.Size = new System.Drawing.Size(66, 23);
            this.PostcodeLBL.TabIndex = 82;
            this.PostcodeLBL.Tag = "newClient";
            this.PostcodeLBL.Text = "Postcode";
            // 
            // AddressTwoLBL
            // 
            this.AddressTwoLBL.AutoSize = true;
            this.AddressTwoLBL.Depth = 0;
            this.AddressTwoLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.AddressTwoLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.AddressTwoLBL.Location = new System.Drawing.Point(544, 239);
            this.AddressTwoLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.AddressTwoLBL.Name = "AddressTwoLBL";
            this.AddressTwoLBL.Size = new System.Drawing.Size(119, 23);
            this.AddressTwoLBL.TabIndex = 81;
            this.AddressTwoLBL.Tag = "newClient";
            this.AddressTwoLBL.Text = "Address Line Two";
            // 
            // addressOneLBL
            // 
            this.addressOneLBL.AutoSize = true;
            this.addressOneLBL.Depth = 0;
            this.addressOneLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.addressOneLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.addressOneLBL.Location = new System.Drawing.Point(544, 180);
            this.addressOneLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.addressOneLBL.Name = "addressOneLBL";
            this.addressOneLBL.Size = new System.Drawing.Size(110, 23);
            this.addressOneLBL.TabIndex = 80;
            this.addressOneLBL.Tag = "newClient";
            this.addressOneLBL.Text = "Address line one";
            // 
            // nameLBL
            // 
            this.nameLBL.AutoSize = true;
            this.nameLBL.Depth = 0;
            this.nameLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.nameLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.nameLBL.Location = new System.Drawing.Point(543, 121);
            this.nameLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.nameLBL.Name = "nameLBL";
            this.nameLBL.Size = new System.Drawing.Size(45, 23);
            this.nameLBL.TabIndex = 79;
            this.nameLBL.Tag = "newClient";
            this.nameLBL.Text = "Name";
            // 
            // dogDGV
            // 
            this.dogDGV.AllowUserToAddRows = false;
            this.dogDGV.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dogDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dogDGV.Location = new System.Drawing.Point(238, 136);
            this.dogDGV.Name = "dogDGV";
            this.dogDGV.Size = new System.Drawing.Size(282, 440);
            this.dogDGV.TabIndex = 59;
            this.dogDGV.Tag = "excistingDog";
            // 
            // addBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 620);
            this.Controls.Add(this.materialLabel4);
            this.Controls.Add(this.clientDGV);
            this.Controls.Add(this.addressLineOne);
            this.Controls.Add(this.nameLineOne);
            this.Controls.Add(this.addressLineTwo);
            this.Controls.Add(this.excistingClientBTN);
            this.Controls.Add(this.NewClientBTN);
            this.Controls.Add(this.cancleBTN);
            this.Controls.Add(this.submitBTN);
            this.Controls.Add(this.PostCodeLine);
            this.Controls.Add(this.paymentCB);
            this.Controls.Add(this.thirdBreaker);
            this.Controls.Add(this.paymentLBL);
            this.Controls.Add(this.PostcodeLBL);
            this.Controls.Add(this.AddressTwoLBL);
            this.Controls.Add(this.addressOneLBL);
            this.Controls.Add(this.nameLBL);
            this.Controls.Add(this.dogDGV);
            this.Controls.Add(this.dogFoodDGV);
            this.Controls.Add(this.vaccineDGV);
            this.Controls.Add(this.totalLBL);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.topBreaker);
            this.Controls.Add(this.selectLBL);
            this.Controls.Add(this.excsitingBTN);
            this.Controls.Add(this.onethirdBreaker);
            this.Controls.Add(this.vaccineLBL);
            this.Controls.Add(this.dogNameTXT);
            this.Controls.Add(this.newDogBTN);
            this.Controls.Add(this.emergancyBTN);
            this.Controls.Add(this.servicesCB);
            this.Controls.Add(this.servicesLBL);
            this.Controls.Add(this.dogNameLBL);
            this.Controls.Add(this.twothirdBreaker);
            this.Controls.Add(this.newBookingCal);
            this.Controls.Add(this.startLBL);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "addBooking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Booking";
            this.Load += new System.EventHandler(this.AddClients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vaccineDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogFoodDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dogDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialLabel startLBL;
        private System.Windows.Forms.MonthCalendar newBookingCal;
        private MaterialSkin.Controls.MaterialDivider twothirdBreaker;
        private MaterialSkin.Controls.MaterialLabel dogNameLBL;
        private MaterialSkin.Controls.MaterialLabel servicesLBL;
        private System.Windows.Forms.ComboBox servicesCB;
        private MaterialSkin.Controls.MaterialCheckBox emergancyBTN;
        private MaterialSkin.Controls.MaterialCheckBox newDogBTN;
        private MaterialSkin.Controls.MaterialSingleLineTextField dogNameTXT;
        private MaterialSkin.Controls.MaterialLabel vaccineLBL;
        private MaterialSkin.Controls.MaterialDivider onethirdBreaker;
        private MaterialSkin.Controls.MaterialCheckBox excsitingBTN;
        private MaterialSkin.Controls.MaterialLabel selectLBL;
        private MaterialSkin.Controls.MaterialDivider topBreaker;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel totalLBL;
        private System.Windows.Forms.DataGridView vaccineDGV;
        private System.Windows.Forms.DataGridView dogFoodDGV;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private System.Windows.Forms.DataGridView clientDGV;
        private MaterialSkin.Controls.MaterialSingleLineTextField addressLineOne;
        private MaterialSkin.Controls.MaterialSingleLineTextField nameLineOne;
        private MaterialSkin.Controls.MaterialSingleLineTextField addressLineTwo;
        private MaterialSkin.Controls.MaterialCheckBox excistingClientBTN;
        private MaterialSkin.Controls.MaterialCheckBox NewClientBTN;
        private MaterialSkin.Controls.MaterialFlatButton cancleBTN;
        private MaterialSkin.Controls.MaterialFlatButton submitBTN;
        private MaterialSkin.Controls.MaterialSingleLineTextField PostCodeLine;
        private System.Windows.Forms.ComboBox paymentCB;
        private MaterialSkin.Controls.MaterialDivider thirdBreaker;
        private MaterialSkin.Controls.MaterialLabel paymentLBL;
        private MaterialSkin.Controls.MaterialLabel PostcodeLBL;
        private MaterialSkin.Controls.MaterialLabel AddressTwoLBL;
        private MaterialSkin.Controls.MaterialLabel addressOneLBL;
        private MaterialSkin.Controls.MaterialLabel nameLBL;
        private System.Windows.Forms.DataGridView dogDGV;
    }
}