﻿namespace JDDogCare_2266.GUI.sub_menues
{
    partial class removeClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dogRadio = new System.Windows.Forms.RadioButton();
            this.clientRadio = new System.Windows.Forms.RadioButton();
            this.bookingRadio = new System.Windows.Forms.RadioButton();
            this.cancelBTN = new System.Windows.Forms.Button();
            this.submitBTN = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dogRadio
            // 
            this.dogRadio.AutoSize = true;
            this.dogRadio.Location = new System.Drawing.Point(0, 16);
            this.dogRadio.Name = "dogRadio";
            this.dogRadio.Size = new System.Drawing.Size(77, 17);
            this.dogRadio.TabIndex = 0;
            this.dogRadio.TabStop = true;
            this.dogRadio.Text = "Delete dog";
            this.dogRadio.UseVisualStyleBackColor = true;
            this.dogRadio.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // clientRadio
            // 
            this.clientRadio.AutoSize = true;
            this.clientRadio.Location = new System.Drawing.Point(91, 16);
            this.clientRadio.Name = "clientRadio";
            this.clientRadio.Size = new System.Drawing.Size(85, 17);
            this.clientRadio.TabIndex = 1;
            this.clientRadio.TabStop = true;
            this.clientRadio.Text = "Delete Client";
            this.clientRadio.UseVisualStyleBackColor = true;
            // 
            // bookingRadio
            // 
            this.bookingRadio.AutoSize = true;
            this.bookingRadio.Location = new System.Drawing.Point(182, 16);
            this.bookingRadio.Name = "bookingRadio";
            this.bookingRadio.Size = new System.Drawing.Size(98, 17);
            this.bookingRadio.TabIndex = 2;
            this.bookingRadio.TabStop = true;
            this.bookingRadio.Text = "Delete Booking";
            this.bookingRadio.UseVisualStyleBackColor = true;
            // 
            // cancelBTN
            // 
            this.cancelBTN.Location = new System.Drawing.Point(322, 34);
            this.cancelBTN.Name = "cancelBTN";
            this.cancelBTN.Size = new System.Drawing.Size(75, 23);
            this.cancelBTN.TabIndex = 3;
            this.cancelBTN.Text = "Cancel";
            this.cancelBTN.UseVisualStyleBackColor = true;
            this.cancelBTN.Click += new System.EventHandler(this.CancelBTN_Click);
            // 
            // submitBTN
            // 
            this.submitBTN.Location = new System.Drawing.Point(403, 34);
            this.submitBTN.Name = "submitBTN";
            this.submitBTN.Size = new System.Drawing.Size(75, 23);
            this.submitBTN.TabIndex = 4;
            this.submitBTN.Text = "Confirm";
            this.submitBTN.UseVisualStyleBackColor = true;
            this.submitBTN.Click += new System.EventHandler(this.Button2_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dogRadio);
            this.panel1.Controls.Add(this.clientRadio);
            this.panel1.Controls.Add(this.bookingRadio);
            this.panel1.Location = new System.Drawing.Point(12, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(295, 56);
            this.panel1.TabIndex = 5;
            // 
            // removeClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 89);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.submitBTN);
            this.Controls.Add(this.cancelBTN);
            this.Name = "removeClient";
            this.Text = "Remove Client";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton dogRadio;
        private System.Windows.Forms.RadioButton clientRadio;
        private System.Windows.Forms.RadioButton bookingRadio;
        private System.Windows.Forms.Button cancelBTN;
        private System.Windows.Forms.Button submitBTN;
        private System.Windows.Forms.Panel panel1;
    }
}