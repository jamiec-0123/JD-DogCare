﻿namespace JDDogCare_2266.GUI
{
    partial class booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchBarTXT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.clientView = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.addClientBTN = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.clientView)).BeginInit();
            this.SuspendLayout();
            // 
            // searchBarTXT
            // 
            this.searchBarTXT.Location = new System.Drawing.Point(153, 92);
            this.searchBarTXT.Name = "searchBarTXT";
            this.searchBarTXT.Size = new System.Drawing.Size(191, 20);
            this.searchBarTXT.TabIndex = 57;
            this.searchBarTXT.TextChanged += new System.EventHandler(this.searchBarTXT_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(154, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 59;
            this.label1.Text = "Search";
            // 
            // clientView
            // 
            this.clientView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.clientView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clientView.Location = new System.Drawing.Point(154, 119);
            this.clientView.Name = "clientView";
            this.clientView.Size = new System.Drawing.Size(567, 499);
            this.clientView.TabIndex = 60;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(347, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 61;
            this.label2.Text = "Add Client";
            // 
            // addClientBTN
            // 
            this.addClientBTN.Location = new System.Drawing.Point(408, 91);
            this.addClientBTN.Name = "addClientBTN";
            this.addClientBTN.Size = new System.Drawing.Size(38, 20);
            this.addClientBTN.TabIndex = 62;
            this.addClientBTN.Text = "ADD";
            this.addClientBTN.UseVisualStyleBackColor = true;
            this.addClientBTN.Click += new System.EventHandler(this.AddClientBTN_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(450, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 63;
            this.label3.Text = "Remove Client";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(532, 91);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(61, 20);
            this.button3.TabIndex = 64;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(599, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 68;
            this.label4.Text = "View payment";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(678, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(43, 21);
            this.button1.TabIndex = 69;
            this.button1.Text = "VIEW";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 620);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.addClientBTN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.clientView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchBarTXT);
            this.Name = "booking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Client";
            this.Load += new System.EventHandler(this.client_Load);
            this.Controls.SetChildIndex(this.dbConnectionBTN, 0);
            this.Controls.SetChildIndex(this.searchBarTXT, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.clientView, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.addClientBTN, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.button3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.clientView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox searchBarTXT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView clientView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addClientBTN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
    }
}