﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.GUI;
using JDDogCare_2266.Objects;

namespace JDDogCare_2266.GUI
{
    public partial class defaultScreen : MaterialSkin.Controls.MaterialForm
    {
        private DataBase db;
        public Thread forms;
        private bool isWorkingOn;
        const int dailyForm = 1, mainMenu = 2, client = 3, addClient = 4, deleteClient = 5, staff = 6, payment = 7, dbConnection = 8, daily = 9, addStaff = 10;
        int _currentScreen;
        public defaultScreen()
        {
            InitializeComponent();
            isWorkingOn = false;
            //Due to the skin overriding the form editor, all changes required will be made here
            bookingBTN.AutoSize = false;
            bookingBTN.Size = new Size(135, 46);
            collcNdelivBTN.AutoSize = false;
            collcNdelivBTN.Size = new Size(135, 46);
            daycareBTN.AutoSize = false;
            daycareBTN.Size = new Size(135, 46);
            daycareBTN.BackColor = Color.Black;
            dbConnectionBTN.AutoSize = false;
            dbConnectionBTN.Size = new Size(135, 49);
            servicesBTN.AutoSize = false;
            servicesBTN.Size = new Size(135, 46);
            paymentBTN.AutoSize = false;
            paymentBTN.Size = new Size(135, 46);
            mobservicesBTN.AutoSize = false;
            mobservicesBTN.Size = new Size(135, 46);
            staffBTN.AutoSize = false;
            staffBTN.Size = new Size(135, 46);
            trainingBTN.AutoSize = false;
            trainingBTN.Size = new Size(135, 46);
            walkingBTN.AutoSize = false;
            walkingBTN.Size = new Size(135, 46);
            mainMenueBTN.AutoSize = false;
            mainMenueBTN.Size = new Size(135, 46);
            Getdb = new DataBase();
            if (Getdb.connect() == true) {
                dbConnectionBTN.Text = "connnected";
            }
        }
        public int CurrentScreen
        {
            get { return _currentScreen; }
            set { _currentScreen = value; }
        }
        public void autoSize(DataGridView dba)
        {

        }
        public defaultScreen(DataBase db)
        {
            Getdb = db;
            //changeScreen(2);
        }

        public DataBase Getdb {
            get { return db; }
            set { db = value; }
        }



        private void DaycareBTN_Click(object sender, EventArgs e)
        {

            this.Hide();
            var form2 = new DailyCareMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        private void MainMenueBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new mainMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void dbConnectionBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new construction();
            form2.Closed += (s, args) => this.Close();
            form2.Show();

        }
        private void trainingBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new construction();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void mobservicesBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new construction();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void DefaultScreen_Load(object sender, EventArgs e)
        {

        }

        private void paymentBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new paymentViewMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void walkingBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new construction();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void collcNdelivBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new construction();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        private void servicesBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new paymentViewMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        private void bookingBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new booking();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        private void staffBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new StaffMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        public bool IsWorkingOn
        {
            get { return isWorkingOn; }
            set { isWorkingOn = value; }
        }
    }
}
