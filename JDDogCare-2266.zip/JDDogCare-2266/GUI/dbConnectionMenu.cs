﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JDDogCare_2266.GUI
{
    public partial class dbConnectionMenu : defaultScreen
    {
        public dbConnectionMenu()
        {
            InitializeComponent();
        }

        private void dbConnectionMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
