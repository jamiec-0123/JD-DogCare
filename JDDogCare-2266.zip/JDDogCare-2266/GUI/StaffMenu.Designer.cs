﻿namespace JDDogCare_2266.GUI
{
    partial class StaffMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        // /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        // protected override void Dispose(bool disposing)
        // {
        //     if (disposing && (components != null))
        //     {
        //         components.Dispose();
        //     }
        //     base.Dispose(disposing);
        // }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.staffDGV = new System.Windows.Forms.DataGridView();
            this.startTimeOff = new System.Windows.Forms.ComboBox();
            this.infoLBL = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.endTimeOff = new System.Windows.Forms.ComboBox();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.nameTXT = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.fullTimeBTN = new MaterialSkin.Controls.MaterialRadioButton();
            this.partTimeBTN = new MaterialSkin.Controls.MaterialRadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.newMemberBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialFlatButton2 = new MaterialSkin.Controls.MaterialFlatButton();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.selectStaffDGV = new System.Windows.Forms.DataGridView();
            this.selectStaffLBL = new MaterialSkin.Controls.MaterialLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.addNewStaffBTN = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.staffDGV)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectStaffDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // staffDGV
            // 
            this.staffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffDGV.Location = new System.Drawing.Point(156, 121);
            this.staffDGV.Name = "staffDGV";
            this.staffDGV.Size = new System.Drawing.Size(427, 488);
            this.staffDGV.TabIndex = 57;
            // 
            // startTimeOff
            // 
            this.startTimeOff.FormattingEnabled = true;
            this.startTimeOff.Location = new System.Drawing.Point(589, 155);
            this.startTimeOff.Name = "startTimeOff";
            this.startTimeOff.Size = new System.Drawing.Size(199, 21);
            this.startTimeOff.TabIndex = 58;
            // 
            // infoLBL
            // 
            this.infoLBL.AutoSize = true;
            this.infoLBL.Depth = 0;
            this.infoLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.infoLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.infoLBL.Location = new System.Drawing.Point(589, 121);
            this.infoLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.infoLBL.Name = "infoLBL";
            this.infoLBL.Size = new System.Drawing.Size(120, 23);
            this.infoLBL.TabIndex = 59;
            this.infoLBL.Text = "Select duration off";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(589, 179);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(124, 23);
            this.materialLabel2.TabIndex = 60;
            this.materialLabel2.Text = "Select replacement";
            // 
            // endTimeOff
            // 
            this.endTimeOff.FormattingEnabled = true;
            this.endTimeOff.Location = new System.Drawing.Point(589, 205);
            this.endTimeOff.Name = "endTimeOff";
            this.endTimeOff.Size = new System.Drawing.Size(199, 21);
            this.endTimeOff.TabIndex = 61;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(156, 87);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(114, 23);
            this.materialLabel1.TabIndex = 62;
            this.materialLabel1.Text = "Find staff on duty";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(589, 406);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(143, 23);
            this.materialLabel3.TabIndex = 65;
            this.materialLabel3.Text = "Add new staff member";
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(589, 431);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(45, 23);
            this.materialLabel4.TabIndex = 66;
            this.materialLabel4.Text = "Name";
            // 
            // nameTXT
            // 
            this.nameTXT.Depth = 0;
            this.nameTXT.EnterToTab = false;
            this.nameTXT.Hint = "";
            this.nameTXT.Location = new System.Drawing.Point(590, 458);
            this.nameTXT.MaxLength = 32767;
            this.nameTXT.MouseState = MaterialSkin.MouseState.Hover;
            this.nameTXT.Name = "nameTXT";
            this.nameTXT.PasswordChar = '\0';
            this.nameTXT.SelectedText = "";
            this.nameTXT.SelectionLength = 0;
            this.nameTXT.SelectionStart = 0;
            this.nameTXT.Size = new System.Drawing.Size(198, 30);
            this.nameTXT.TabIndex = 67;
            this.nameTXT.TabStop = false;
            this.nameTXT.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.nameTXT.UseSystemPasswordChar = false;
            // 
            // fullTimeBTN
            // 
            this.fullTimeBTN.AutoSize = true;
            this.fullTimeBTN.Depth = 0;
            this.fullTimeBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.fullTimeBTN.Location = new System.Drawing.Point(3, 5);
            this.fullTimeBTN.Margin = new System.Windows.Forms.Padding(0);
            this.fullTimeBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.fullTimeBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.fullTimeBTN.Name = "fullTimeBTN";
            this.fullTimeBTN.Ripple = true;
            this.fullTimeBTN.Size = new System.Drawing.Size(81, 30);
            this.fullTimeBTN.TabIndex = 68;
            this.fullTimeBTN.TabStop = true;
            this.fullTimeBTN.Text = "full time";
            this.fullTimeBTN.UseVisualStyleBackColor = true;
            // 
            // partTimeBTN
            // 
            this.partTimeBTN.AutoSize = true;
            this.partTimeBTN.Depth = 0;
            this.partTimeBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.partTimeBTN.Location = new System.Drawing.Point(108, 5);
            this.partTimeBTN.Margin = new System.Windows.Forms.Padding(0);
            this.partTimeBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.partTimeBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.partTimeBTN.Name = "partTimeBTN";
            this.partTimeBTN.Ripple = true;
            this.partTimeBTN.Size = new System.Drawing.Size(87, 30);
            this.partTimeBTN.TabIndex = 69;
            this.partTimeBTN.TabStop = true;
            this.partTimeBTN.Text = "part time";
            this.partTimeBTN.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.fullTimeBTN);
            this.panel1.Controls.Add(this.partTimeBTN);
            this.panel1.Location = new System.Drawing.Point(589, 494);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 41);
            this.panel1.TabIndex = 70;
            // 
            // newMemberBTN
            // 
            this.newMemberBTN.AutoSize = true;
            this.newMemberBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.newMemberBTN.Depth = 0;
            this.newMemberBTN.Icon = null;
            this.newMemberBTN.Location = new System.Drawing.Point(589, 544);
            this.newMemberBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.newMemberBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.newMemberBTN.Name = "newMemberBTN";
            this.newMemberBTN.Primary = false;
            this.newMemberBTN.Size = new System.Drawing.Size(147, 36);
            this.newMemberBTN.TabIndex = 71;
            this.newMemberBTN.Text = "Add New member";
            this.newMemberBTN.UseVisualStyleBackColor = true;
            // 
            // materialFlatButton2
            // 
            this.materialFlatButton2.AutoSize = true;
            this.materialFlatButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton2.Depth = 0;
            this.materialFlatButton2.Icon = null;
            this.materialFlatButton2.Location = new System.Drawing.Point(590, 233);
            this.materialFlatButton2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialFlatButton2.Name = "materialFlatButton2";
            this.materialFlatButton2.Primary = false;
            this.materialFlatButton2.Size = new System.Drawing.Size(115, 36);
            this.materialFlatButton2.TabIndex = 72;
            this.materialFlatButton2.Text = "Add time off";
            this.materialFlatButton2.UseVisualStyleBackColor = true;
            // 
            // datePicker
            // 
            this.datePicker.Location = new System.Drawing.Point(276, 90);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(200, 20);
            this.datePicker.TabIndex = 73;
            // 
            // selectStaffDGV
            // 
            this.selectStaffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selectStaffDGV.Location = new System.Drawing.Point(151, 107);
            this.selectStaffDGV.Name = "selectStaffDGV";
            this.selectStaffDGV.Size = new System.Drawing.Size(507, 512);
            this.selectStaffDGV.TabIndex = 57;
            // 
            // selectStaffLBL
            // 
            this.selectStaffLBL.AutoSize = true;
            this.selectStaffLBL.Depth = 0;
            this.selectStaffLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.selectStaffLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.selectStaffLBL.Location = new System.Drawing.Point(151, 79);
            this.selectStaffLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.selectStaffLBL.Name = "selectStaffLBL";
            this.selectStaffLBL.Size = new System.Drawing.Size(39, 23);
            this.selectStaffLBL.TabIndex = 58;
            this.selectStaffLBL.Text = "Staff ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(262, 81);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 59;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(468, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 23);
            this.button1.TabIndex = 63;
            this.button1.Text = "ADD TIME OFF";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // addNewStaffBTN
            // 
            this.addNewStaffBTN.Location = new System.Drawing.Point(565, 79);
            this.addNewStaffBTN.Name = "addNewStaffBTN";
            this.addNewStaffBTN.Size = new System.Drawing.Size(93, 23);
            this.addNewStaffBTN.TabIndex = 64;
            this.addNewStaffBTN.Text = "Add New Staff";
            this.addNewStaffBTN.UseVisualStyleBackColor = true;
            this.addNewStaffBTN.Click += new System.EventHandler(this.AddNewStaffBTN_Click);
            // 
            // StaffMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(660, 621);
            this.Controls.Add(this.addNewStaffBTN);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.selectStaffLBL);
            this.Controls.Add(this.selectStaffDGV);
            this.Name = "StaffMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staff";
            this.Load += new System.EventHandler(this.StaffMenu_Load);
            this.Controls.SetChildIndex(this.dbConnectionBTN, 0);
            this.Controls.SetChildIndex(this.selectStaffDGV, 0);
            this.Controls.SetChildIndex(this.selectStaffLBL, 0);
            this.Controls.SetChildIndex(this.dateTimePicker1, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.addNewStaffBTN, 0);
            ((System.ComponentModel.ISupportInitialize)(this.staffDGV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectStaffDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView staffDGV;
        private System.Windows.Forms.ComboBox startTimeOff;
        private MaterialSkin.Controls.MaterialLabel infoLBL;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private System.Windows.Forms.ComboBox endTimeOff;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialSingleLineTextField nameTXT;
        private MaterialSkin.Controls.MaterialRadioButton fullTimeBTN;
        private MaterialSkin.Controls.MaterialRadioButton partTimeBTN;
        private System.Windows.Forms.Panel panel1;
        private MaterialSkin.Controls.MaterialFlatButton newMemberBTN;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton2;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.DataGridView selectStaffDGV;
        private MaterialSkin.Controls.MaterialLabel selectStaffLBL;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button addNewStaffBTN;
    }
}