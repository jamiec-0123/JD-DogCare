﻿namespace JDDogCare_2266.GUI
{
    partial class DailyCareMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DailyCareMenu));
            this.selectDateBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.dayCareSheet = new System.Windows.Forms.DataGridView();
            this.staffLBL = new MaterialSkin.Controls.MaterialLabel();
            this.materialDivider5 = new MaterialSkin.Controls.MaterialDivider();
            this.addStaffBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.staffTable = new System.Windows.Forms.DataGridView();
            this.detailedViewLBL = new System.Windows.Forms.Label();
            this.incidentTable = new System.Windows.Forms.DataGridView();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.incidentAddBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.EditInfo = new MaterialSkin.Controls.MaterialFlatButton();
            this.NewClientBTN = new MaterialSkin.Controls.MaterialCheckBox();
            this.materialCheckBox1 = new MaterialSkin.Controls.MaterialCheckBox();
            this.materialCheckBox2 = new MaterialSkin.Controls.MaterialCheckBox();
            this.materialCheckBox3 = new MaterialSkin.Controls.MaterialCheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.print = new MaterialSkin.Controls.MaterialFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.dayCareSheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.incidentTable)).BeginInit();
            this.SuspendLayout();
            // 
            // selectDateBTN
            // 
            this.selectDateBTN.AutoSize = true;
            this.selectDateBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectDateBTN.Depth = 0;
            this.selectDateBTN.Icon = null;
            this.selectDateBTN.Location = new System.Drawing.Point(536, 84);
            this.selectDateBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectDateBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.selectDateBTN.Name = "selectDateBTN";
            this.selectDateBTN.Primary = false;
            this.selectDateBTN.Size = new System.Drawing.Size(71, 36);
            this.selectDateBTN.TabIndex = 34;
            this.selectDateBTN.Text = "SELECT";
            this.selectDateBTN.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.selectDateBTN.UseVisualStyleBackColor = true;
            this.selectDateBTN.Click += new System.EventHandler(this.selectDateBTN_Click);
            // 
            // datePicker
            // 
            this.datePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicker.Location = new System.Drawing.Point(156, 82);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(372, 38);
            this.datePicker.TabIndex = 35;
            this.datePicker.Value = new System.DateTime(2020, 1, 2, 13, 26, 39, 0);
            // 
            // dayCareSheet
            // 
            this.dayCareSheet.AllowUserToAddRows = false;
            this.dayCareSheet.AllowUserToDeleteRows = false;
            this.dayCareSheet.AllowUserToResizeColumns = false;
            this.dayCareSheet.AllowUserToResizeRows = false;
            this.dayCareSheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dayCareSheet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dayCareSheet.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dayCareSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dayCareSheet.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dayCareSheet.Location = new System.Drawing.Point(156, 123);
            this.dayCareSheet.Name = "dayCareSheet";
            this.dayCareSheet.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dayCareSheet.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dayCareSheet.Size = new System.Drawing.Size(451, 495);
            this.dayCareSheet.TabIndex = 36;
            this.dayCareSheet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dayCareSheet_CellContentClick);
            this.dayCareSheet.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dayCareSheet_CellValueChanged);
            this.dayCareSheet.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dayCareSheet_UserAddedRow);
            // 
            // staffLBL
            // 
            this.staffLBL.AutoSize = true;
            this.staffLBL.Depth = 0;
            this.staffLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.staffLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.staffLBL.Location = new System.Drawing.Point(616, 87);
            this.staffLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.staffLBL.Name = "staffLBL";
            this.staffLBL.Size = new System.Drawing.Size(89, 23);
            this.staffLBL.TabIndex = 37;
            this.staffLBL.Tag = "moveable";
            this.staffLBL.Text = "Staff On Duty";
            // 
            // materialDivider5
            // 
            this.materialDivider5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialDivider5.Depth = 0;
            this.materialDivider5.Location = new System.Drawing.Point(705, 74);
            this.materialDivider5.MouseState = MaterialSkin.MouseState.Hover;
            this.materialDivider5.Name = "materialDivider5";
            this.materialDivider5.Size = new System.Drawing.Size(10, 574);
            this.materialDivider5.TabIndex = 42;
            this.materialDivider5.Text = "materialDivider5";
            // 
            // addStaffBTN
            // 
            this.addStaffBTN.AutoSize = true;
            this.addStaffBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.addStaffBTN.Depth = 0;
            this.addStaffBTN.Icon = null;
            this.addStaffBTN.Location = new System.Drawing.Point(761, 79);
            this.addStaffBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.addStaffBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.addStaffBTN.Name = "addStaffBTN";
            this.addStaffBTN.Primary = false;
            this.addStaffBTN.Size = new System.Drawing.Size(50, 36);
            this.addStaffBTN.TabIndex = 45;
            this.addStaffBTN.Tag = "moveable";
            this.addStaffBTN.Text = "ADD";
            this.addStaffBTN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addStaffBTN.UseVisualStyleBackColor = true;
            this.addStaffBTN.Click += new System.EventHandler(this.addStaffBTN_Click);
            // 
            // staffTable
            // 
            this.staffTable.AllowUserToAddRows = false;
            this.staffTable.AllowUserToDeleteRows = false;
            this.staffTable.AllowUserToResizeColumns = false;
            this.staffTable.AllowUserToResizeRows = false;
            this.staffTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.staffTable.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.staffTable.BackgroundColor = System.Drawing.SystemColors.Control;
            this.staffTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffTable.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.staffTable.Location = new System.Drawing.Point(616, 123);
            this.staffTable.Name = "staffTable";
            this.staffTable.ShowCellErrors = false;
            this.staffTable.ShowCellToolTips = false;
            this.staffTable.ShowEditingIcon = false;
            this.staffTable.ShowRowErrors = false;
            this.staffTable.Size = new System.Drawing.Size(327, 207);
            this.staffTable.TabIndex = 69;
            this.staffTable.Tag = "moveable";
            this.staffTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StaffTable_CellContentClick);
            // 
            // detailedViewLBL
            // 
            this.detailedViewLBL.AutoSize = true;
            this.detailedViewLBL.Location = new System.Drawing.Point(1210, 76);
            this.detailedViewLBL.Name = "detailedViewLBL";
            this.detailedViewLBL.Size = new System.Drawing.Size(71, 13);
            this.detailedViewLBL.TabIndex = 71;
            this.detailedViewLBL.Text = "Detailed veiw";
            // 
            // incidentTable
            // 
            this.incidentTable.AllowUserToAddRows = false;
            this.incidentTable.AllowUserToDeleteRows = false;
            this.incidentTable.AllowUserToResizeColumns = false;
            this.incidentTable.AllowUserToResizeRows = false;
            this.incidentTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.incidentTable.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.incidentTable.BackgroundColor = System.Drawing.SystemColors.Control;
            this.incidentTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.incidentTable.Location = new System.Drawing.Point(616, 369);
            this.incidentTable.Name = "incidentTable";
            this.incidentTable.ShowCellErrors = false;
            this.incidentTable.ShowCellToolTips = false;
            this.incidentTable.ShowEditingIcon = false;
            this.incidentTable.ShowRowErrors = false;
            this.incidentTable.Size = new System.Drawing.Size(327, 207);
            this.incidentTable.TabIndex = 99;
            this.incidentTable.Tag = "moveable";
            this.incidentTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.IncidentTable_CellContentClick);
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(616, 335);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(67, 23);
            this.materialLabel2.TabIndex = 100;
            this.materialLabel2.Tag = "moveable";
            this.materialLabel2.Text = "Incidents";
            // 
            // incidentAddBTN
            // 
            this.incidentAddBTN.AutoSize = true;
            this.incidentAddBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.incidentAddBTN.Depth = 0;
            this.incidentAddBTN.Icon = null;
            this.incidentAddBTN.Location = new System.Drawing.Point(706, 327);
            this.incidentAddBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.incidentAddBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.incidentAddBTN.Name = "incidentAddBTN";
            this.incidentAddBTN.Primary = false;
            this.incidentAddBTN.Size = new System.Drawing.Size(50, 36);
            this.incidentAddBTN.TabIndex = 101;
            this.incidentAddBTN.Tag = "moveable";
            this.incidentAddBTN.Text = "ADD";
            this.incidentAddBTN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.incidentAddBTN.UseVisualStyleBackColor = true;
            this.incidentAddBTN.Click += new System.EventHandler(this.IncidentAddBTN_Click);
            // 
            // EditInfo
            // 
            this.EditInfo.AutoSize = true;
            this.EditInfo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.EditInfo.Depth = 0;
            this.EditInfo.Icon = null;
            this.EditInfo.Location = new System.Drawing.Point(613, 79);
            this.EditInfo.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.EditInfo.MouseState = MaterialSkin.MouseState.Hover;
            this.EditInfo.Name = "EditInfo";
            this.EditInfo.Primary = false;
            this.EditInfo.Size = new System.Drawing.Size(152, 36);
            this.EditInfo.TabIndex = 61;
            this.EditInfo.Tag = "grayAble";
            this.EditInfo.Text = "Edit Information";
            this.EditInfo.UseVisualStyleBackColor = true;
            this.EditInfo.Visible = false;
            this.EditInfo.Click += new System.EventHandler(this.editInfo_Click);
            // 
            // NewClientBTN
            // 
            this.NewClientBTN.AutoSize = true;
            this.NewClientBTN.Depth = 0;
            this.NewClientBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.NewClientBTN.Location = new System.Drawing.Point(616, 208);
            this.NewClientBTN.Margin = new System.Windows.Forms.Padding(0);
            this.NewClientBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.NewClientBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.NewClientBTN.Name = "NewClientBTN";
            this.NewClientBTN.Ripple = true;
            this.NewClientBTN.Size = new System.Drawing.Size(70, 30);
            this.NewClientBTN.TabIndex = 85;
            this.NewClientBTN.Tag = "grayable";
            this.NewClientBTN.Text = "Walk 1";
            this.NewClientBTN.UseVisualStyleBackColor = true;
            this.NewClientBTN.Visible = false;
            // 
            // materialCheckBox1
            // 
            this.materialCheckBox1.AutoSize = true;
            this.materialCheckBox1.Depth = 0;
            this.materialCheckBox1.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialCheckBox1.Location = new System.Drawing.Point(616, 171);
            this.materialCheckBox1.Margin = new System.Windows.Forms.Padding(0);
            this.materialCheckBox1.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialCheckBox1.MouseState = MaterialSkin.MouseState.Hover;
            this.materialCheckBox1.Name = "materialCheckBox1";
            this.materialCheckBox1.Ripple = true;
            this.materialCheckBox1.Size = new System.Drawing.Size(54, 30);
            this.materialCheckBox1.TabIndex = 86;
            this.materialCheckBox1.Tag = "grayable";
            this.materialCheckBox1.Text = "Fed";
            this.materialCheckBox1.UseVisualStyleBackColor = true;
            this.materialCheckBox1.Visible = false;
            // 
            // materialCheckBox2
            // 
            this.materialCheckBox2.AutoSize = true;
            this.materialCheckBox2.Depth = 0;
            this.materialCheckBox2.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialCheckBox2.Location = new System.Drawing.Point(613, 249);
            this.materialCheckBox2.Margin = new System.Windows.Forms.Padding(0);
            this.materialCheckBox2.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialCheckBox2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialCheckBox2.Name = "materialCheckBox2";
            this.materialCheckBox2.Ripple = true;
            this.materialCheckBox2.Size = new System.Drawing.Size(73, 30);
            this.materialCheckBox2.TabIndex = 87;
            this.materialCheckBox2.Tag = "grayable";
            this.materialCheckBox2.Text = "Walk 2";
            this.materialCheckBox2.UseVisualStyleBackColor = true;
            this.materialCheckBox2.Visible = false;
            // 
            // materialCheckBox3
            // 
            this.materialCheckBox3.AutoSize = true;
            this.materialCheckBox3.Depth = 0;
            this.materialCheckBox3.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.materialCheckBox3.Location = new System.Drawing.Point(616, 296);
            this.materialCheckBox3.Margin = new System.Windows.Forms.Padding(0);
            this.materialCheckBox3.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialCheckBox3.MouseState = MaterialSkin.MouseState.Hover;
            this.materialCheckBox3.Name = "materialCheckBox3";
            this.materialCheckBox3.Ripple = true;
            this.materialCheckBox3.Size = new System.Drawing.Size(83, 30);
            this.materialCheckBox3.TabIndex = 94;
            this.materialCheckBox3.Tag = "grayAble";
            this.materialCheckBox3.Text = "Incident";
            this.materialCheckBox3.UseVisualStyleBackColor = true;
            this.materialCheckBox3.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(624, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 102;
            this.button1.Tag = "grayable";
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // print
            // 
            this.print.AutoSize = true;
            this.print.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.print.Depth = 0;
            this.print.Icon = null;
            this.print.Location = new System.Drawing.Point(764, 331);
            this.print.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.print.MouseState = MaterialSkin.MouseState.Hover;
            this.print.Name = "print";
            this.print.Primary = false;
            this.print.Size = new System.Drawing.Size(63, 36);
            this.print.TabIndex = 103;
            this.print.Tag = "moveable";
            this.print.Text = "Print";
            this.print.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.print.UseVisualStyleBackColor = true;
            this.print.Click += new System.EventHandler(this.Print_Click);
            // 
            // DailyCareMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 622);
            this.Controls.Add(this.print);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.incidentAddBTN);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.incidentTable);
            this.Controls.Add(this.materialCheckBox3);
            this.Controls.Add(this.materialCheckBox2);
            this.Controls.Add(this.materialCheckBox1);
            this.Controls.Add(this.NewClientBTN);
            this.Controls.Add(this.detailedViewLBL);
            this.Controls.Add(this.staffTable);
            this.Controls.Add(this.EditInfo);
            this.Controls.Add(this.addStaffBTN);
            this.Controls.Add(this.staffLBL);
            this.Controls.Add(this.dayCareSheet);
            this.Controls.Add(this.datePicker);
            this.Controls.Add(this.selectDateBTN);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DailyCareMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "moveable";
            this.Text = "Daily Care";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DailyCareMenu_FormClosing);
            this.Load += new System.EventHandler(this.DailyCareMenu_Load);
            this.Controls.SetChildIndex(this.selectDateBTN, 0);
            this.Controls.SetChildIndex(this.datePicker, 0);
            this.Controls.SetChildIndex(this.dayCareSheet, 0);
            this.Controls.SetChildIndex(this.staffLBL, 0);
            this.Controls.SetChildIndex(this.addStaffBTN, 0);
            this.Controls.SetChildIndex(this.EditInfo, 0);
            this.Controls.SetChildIndex(this.staffTable, 0);
            this.Controls.SetChildIndex(this.detailedViewLBL, 0);
            this.Controls.SetChildIndex(this.NewClientBTN, 0);
            this.Controls.SetChildIndex(this.materialCheckBox1, 0);
            this.Controls.SetChildIndex(this.materialCheckBox2, 0);
            this.Controls.SetChildIndex(this.materialCheckBox3, 0);
            this.Controls.SetChildIndex(this.incidentTable, 0);
            this.Controls.SetChildIndex(this.materialLabel2, 0);
            this.Controls.SetChildIndex(this.incidentAddBTN, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.print, 0);
            this.Controls.SetChildIndex(this.dbConnectionBTN, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dayCareSheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.incidentTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialFlatButton selectDateBTN;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.DataGridView dayCareSheet;
        private MaterialSkin.Controls.MaterialLabel staffLBL;
        private MaterialSkin.Controls.MaterialDivider materialDivider5;
        private MaterialSkin.Controls.MaterialFlatButton addStaffBTN;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridView staffTable;
        private System.Windows.Forms.Label detailedViewLBL;
        private System.Windows.Forms.DataGridView incidentTable;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialFlatButton incidentAddBTN;
        private MaterialSkin.Controls.MaterialFlatButton EditInfo;
        private MaterialSkin.Controls.MaterialCheckBox NewClientBTN;
        private MaterialSkin.Controls.MaterialCheckBox materialCheckBox1;
        private MaterialSkin.Controls.MaterialCheckBox materialCheckBox2;
        private MaterialSkin.Controls.MaterialCheckBox materialCheckBox3;
        private System.Windows.Forms.Button button1;
        private MaterialSkin.Controls.MaterialFlatButton print;
    }
}