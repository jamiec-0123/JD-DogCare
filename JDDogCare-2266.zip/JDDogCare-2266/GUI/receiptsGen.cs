﻿namespace JDDogCare_2266.GUI
{


    partial class receiptsGen
    {
    }
}
