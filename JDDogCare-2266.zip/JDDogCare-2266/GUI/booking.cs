﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.GUI;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;
using JDDogCare_2266.GUI.sub_menues;

namespace JDDogCare_2266.GUI
{
    public partial class booking : defaultScreen
    {
        private DataTable clientTable;
        private DataBase DB;
        private string[] servicesOptions = {"None","Regular","Regualr + nails","Regular with nails + ear"};
        List<Tuple<Dogs, Client, Booking, Billing>> bookingData;
        ClientDBAccess clientBD;
        bookingDBAccess bookingDB;
        public booking()
        {
            this.DB = base.Getdb;
            bookingDB = new bookingDBAccess(DB);
            InitializeComponent();
        }

        private void client_Load(object sender, EventArgs e)
        {
            clientBD = new ClientDBAccess(DB);
            update();
            base.CurrentScreen = 3;
        }
        private void searchBarTXT_TextChanged(object sender, EventArgs e)
        {
            update();
        }
        public void update()
        {
            bookingData = clientBD.GetAllClientsInfo(searchBarTXT.Text);
            clientTable = new DataTable();
            clientTable.Columns.Add("Dog name");
            clientTable.Columns.Add("Client name");
            clientTable.Columns.Add("Emergancy");
            clientTable.Columns.Add("services option");
            clientTable.Columns.Add("Trial");
            foreach (Tuple<Dogs, Client, Booking,Billing> data in bookingData)
            {
                clientTable.Rows.Add(data.Item1.Dogname, data.Item2.Clientname, data.Item3.EmergancyCare.ToString(), data.Item3.services);
            }
            clientView.DataSource = clientTable;

        }
        private void AddClientBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new sub_menues.addBooking(Getdb);
            form2.Closed += (s, args) => this.Close();
            form2.Show();
            update();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            bool selected = false;
            List<Tuple<Dogs, Client, Booking,Billing>> editedRow = new List<Tuple<Dogs, Client, Booking,Billing>>();
            for (int index = 0; index < clientView.Rows.Count; index++)
            {
                if (clientView.Rows[index].Selected == true)
                {
                    editedRow.Add(bookingData[index]);
                    selected = true;
                }
            }
            if(selected == true)
            {
                var form2 = new sub_menues.removeClient(editedRow,DB);
                form2.ShowDialog();
                form2.Closed += (s, args) => this.Close();
                update();
            }
            else
            {
                MessageBox.Show("No rows selected", "Error");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            var form2 = new paymentViewMenu();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
            update();

        }
    }
}
