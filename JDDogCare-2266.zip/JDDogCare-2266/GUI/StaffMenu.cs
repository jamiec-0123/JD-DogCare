using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.GUI;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.GUI
{
    public partial class StaffMenu : defaultScreen
    {
        DataTable staffOnScreen;
        staffDBAcess staffDB;
        List<staff> dbData;
        public StaffMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            var form2 = new sub_menues.staffTimeOff(Getdb);
            form2.ShowDialog();
        }

        private void toolStripDropDownMenu1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void ServicesCB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void StaffMenu_Load(object sender, EventArgs e)
        {
            staffDB = new staffDBAcess(Getdb);
            staffOnScreen = new DataTable();
            dbData = new List<staff>(staffDB.getAllStaffNamesAndIDs());
            base.CurrentScreen = 6;
            staffOnScreen.Columns.Add("Name");
            staffOnScreen.Columns.Add("Morning");
            staffOnScreen.Columns.Add("Evening");
            staffOnScreen.Columns.Add("Mon");
            staffOnScreen.Columns.Add("Tues");
            staffOnScreen.Columns.Add("Wends");
            staffOnScreen.Columns.Add("Thurs");
            staffOnScreen.Columns.Add("Fri");
            foreach (staff data in dbData)
            {
                string debugthing = ("" + data.Name + boolToYesNo(data.Morning) + boolToYesNo(data.Afternoon) + boolToYesNo(data.getDayOfWeek(0)) + boolToYesNo(data.getDayOfWeek(1)) + boolToYesNo(data.getDayOfWeek(2)) + boolToYesNo(data.getDayOfWeek(3)) + boolToYesNo(data.getDayOfWeek(4)) + "");
                staffOnScreen.Rows.Add(data.Name, data.Morning.ToString(), data.Afternoon.ToString(),data.getDayOfWeek(0).ToString(), data.getDayOfWeek(1).ToString(), data.getDayOfWeek(2).ToString(),data.getDayOfWeek(3).ToString(), data.getDayOfWeek(4).ToString());
            }
            staffDGV.DataSource = staffOnScreen;
        }
        public string boolToYesNo(bool test)
        {
            string result;
            if (test == true)
            {
                result = "yes";
            }
            else
            {
                result = "No";
            }
            return result;
        }

        private void AddNewStaffBTN_Click(object sender, EventArgs e)
        {
            var form2 = new sub_menues.addNewStaff(Getdb);
            form2.ShowDialog();
        }
    }
}