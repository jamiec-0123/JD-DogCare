﻿namespace JDDogCare_2266.GUI
{
    partial class mainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainMenu));
            this.notificationsInfoLBL = new MaterialSkin.Controls.MaterialLabel();
            this.notificationLBL = new MaterialSkin.Controls.MaterialLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // notificationsInfoLBL
            // 
            this.notificationsInfoLBL.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.notificationsInfoLBL.Depth = 0;
            this.notificationsInfoLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.notificationsInfoLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notificationsInfoLBL.Location = new System.Drawing.Point(156, 74);
            this.notificationsInfoLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.notificationsInfoLBL.Name = "notificationsInfoLBL";
            this.notificationsInfoLBL.Size = new System.Drawing.Size(440, 28);
            this.notificationsInfoLBL.TabIndex = 2;
            this.notificationsInfoLBL.Text = "Notifications";
            this.notificationsInfoLBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // notificationLBL
            // 
            this.notificationLBL.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.notificationLBL.Depth = 0;
            this.notificationLBL.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.notificationLBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notificationLBL.Location = new System.Drawing.Point(156, 131);
            this.notificationLBL.MouseState = MaterialSkin.MouseState.Hover;
            this.notificationLBL.Name = "notificationLBL";
            this.notificationLBL.Size = new System.Drawing.Size(521, 486);
            this.notificationLBL.TabIndex = 4;
            this.notificationLBL.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(602, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 57;
            this.button1.Text = "HELP";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(584, 105);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 23);
            this.button2.TabIndex = 58;
            this.button2.Text = "Generate Today";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // mainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 625);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.notificationLBL);
            this.Controls.Add(this.notificationsInfoLBL);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "mainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Controls.SetChildIndex(this.dbConnectionBTN, 0);
            this.Controls.SetChildIndex(this.notificationsInfoLBL, 0);
            this.Controls.SetChildIndex(this.notificationLBL, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.button2, 0);
            this.ResumeLayout(false);

        }

        #endregion
        private MaterialSkin.Controls.MaterialLabel notificationsInfoLBL;
        private MaterialSkin.Controls.MaterialLabel notificationLBL;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

