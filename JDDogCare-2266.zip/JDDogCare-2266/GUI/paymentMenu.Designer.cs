﻿namespace JDDogCare_2266.GUI
{
    partial class paymentViewMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.detailsDGV = new System.Windows.Forms.DataGridView();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.payedBTN = new MaterialSkin.Controls.MaterialCheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.detailsDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // detailsDGV
            // 
            this.detailsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.detailsDGV.Location = new System.Drawing.Point(157, 121);
            this.detailsDGV.Name = "detailsDGV";
            this.detailsDGV.Size = new System.Drawing.Size(534, 420);
            this.detailsDGV.TabIndex = 0;
            this.detailsDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DetailsDGV_CellContentClick);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(296, 94);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(134, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Viewed Late Payments";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(436, 94);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(86, 17);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "View Unpaid";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(156, 94);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(134, 20);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Icon = null;
            this.materialFlatButton1.Location = new System.Drawing.Point(368, 550);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.Hover;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(152, 36);
            this.materialFlatButton1.TabIndex = 11;
            this.materialFlatButton1.Text = "Generate Recepit";
            this.materialFlatButton1.UseVisualStyleBackColor = true;
            this.materialFlatButton1.Click += new System.EventHandler(this.MaterialFlatButton1_Click);
            // 
            // payedBTN
            // 
            this.payedBTN.AutoSize = true;
            this.payedBTN.Depth = 0;
            this.payedBTN.Font = new System.Drawing.Font("Nazanintar", 11F);
            this.payedBTN.Location = new System.Drawing.Point(153, 555);
            this.payedBTN.Margin = new System.Windows.Forms.Padding(0);
            this.payedBTN.MouseLocation = new System.Drawing.Point(-1, -1);
            this.payedBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.payedBTN.Name = "payedBTN";
            this.payedBTN.Ripple = true;
            this.payedBTN.Size = new System.Drawing.Size(69, 30);
            this.payedBTN.TabIndex = 17;
            this.payedBTN.Text = "Payed";
            this.payedBTN.UseVisualStyleBackColor = true;
            this.payedBTN.Visible = false;
            this.payedBTN.CheckedChanged += new System.EventHandler(this.PayedBTN_CheckedChanged);
            // 
            // paymentViewMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 620);
            this.Controls.Add(this.payedBTN);
            this.Controls.Add(this.materialFlatButton1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.detailsDGV);
            this.Name = "paymentViewMenu";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "updatePayment";
            this.Load += new System.EventHandler(this.UpdatePayment_Load);
            this.Controls.SetChildIndex(this.detailsDGV, 0);
            this.Controls.SetChildIndex(this.checkBox1, 0);
            this.Controls.SetChildIndex(this.checkBox2, 0);
            this.Controls.SetChildIndex(this.dateTimePicker1, 0);
            this.Controls.SetChildIndex(this.materialFlatButton1, 0);
            this.Controls.SetChildIndex(this.payedBTN, 0);
            this.Controls.SetChildIndex(this.dbConnectionBTN, 0);
            ((System.ComponentModel.ISupportInitialize)(this.detailsDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView detailsDGV;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
        private MaterialSkin.Controls.MaterialCheckBox payedBTN;
    }
}