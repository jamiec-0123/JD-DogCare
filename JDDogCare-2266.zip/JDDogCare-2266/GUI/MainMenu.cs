﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;

namespace JDDogCare_2266.GUI
{
    public partial class mainMenu : defaultScreen
    {
        public mainMenu()
        {
            InitializeComponent();
            if(Getdb.connect() == true)
            {
                dbConnectionBTN.Text = "connected";
            }
            else
            {
                dbConnectionBTN.Text = "error";
                MessageBox.Show("Error connectibng to Database, please ensure the DataSource is SQLEXPRESS & Database name is JD-DogCare");
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //notification lable and notification info changes 
            notificationsInfoLBL.Font = new Font(notificationsInfoLBL.Font.Name, 12, FontStyle.Bold);
            notificationLBL.Font = new Font("Bahnschrift", notificationLBL.Font.Size);
            base.CurrentScreen = 2;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new JDDogCare_2266.GUI.sub_menues.generateDaily(Getdb);
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
    }
}
