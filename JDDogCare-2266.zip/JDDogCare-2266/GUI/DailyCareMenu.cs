﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using JDDogCare_2266.Objects;
using JDDogCare_2266.DBAccess;
using JDDogCare_2266.Validation;

namespace JDDogCare_2266.GUI
{
    public partial class DailyCareMenu : defaultScreen
    {
        private List<Tuple<Dogs, staff, Daily>> dbDailyData;
        private List<Tuple<Incident, Dogs>> IncidentData;
        private DataBase db;
        private DataTable staff, daily, incident;
        private bool _exstended =false;
        private DateTime _selectedDate;
        private dateValidation validationDate;
        private DailyDBAcess dailyDB;
        private incidentDBAccess IncidentDB;
          
        public DailyCareMenu()
        {
            validationDate = new dateValidation();
            this.db = base.Getdb;
            dailyDB = new DailyDBAcess(db);
            IncidentDB = new incidentDBAccess(db);
            daily = new DataTable();
            staff = new DataTable();
            incident = new DataTable();
            daily.Columns.Add("Dog Name");
            daily.Columns.Add("Staff Member");
            daily.Columns.Add("Fed");
            daily.Columns.Add("No OfWalks");
            staff.Columns.Add("Staff Name");
            staff.Columns.Add("Morning");
            staff.Columns.Add("Afternoon");
            incident.Columns.Add("Dog");
            incident.Columns.Add("Further Informations");
            InitializeComponent();
            datePicker.Value = DateTime.Now;
        }

        private void DailyCareMenu_Load(object sender, EventArgs e)
        {
            //notification lable and notification info changes 
            detailedViewLBL.Font = new Font("Century", 11);
            staffLBL.Font = new Font(detailedViewLBL.Font.Name, 11, FontStyle.Bold);
            addStaffBTN.AutoSize = false;
            addStaffBTN.Size = new Size(36, 23);
            selectDateBTN.AutoSize = false;
            selectDateBTN.Size = new Size(82, 23);
            selectDateBTN.Font=new Font(detailedViewLBL.Font.Name, 100000, FontStyle.Bold);
            autoSize(dayCareSheet);
            autoSize(staffTable);
            autoSize(incidentTable);
            base.CurrentScreen = 1;
        }

        private void selectDateBTN_Click(object sender, EventArgs e)
        {   
            updateDayCareTable();
        }
        public void updateDayCareTable()
        {
            daily.Rows.Clear();
            staff.Rows.Clear();
            if (validationDate.BusinessDaysUntil(datePicker.Value, datePicker.Value) > 0)
            {
                dbDailyData = dailyDB.getDay(datePicker.Value);
                IncidentData = IncidentDB.getIncidentsViaDate(datePicker.Value);
                foreach (Tuple<Dogs, staff, Daily> dayCareData in dbDailyData)
                {
                    daily.Rows.Add(dayCareData.Item1.Dogname, dayCareData.Item2.Name, dayCareData.Item3.Fed, dayCareData.Item3.noOfWalks);
                    staff.Rows.Add(dayCareData.Item2.Name, dayCareData.Item2.Morning.ToString(), dayCareData.Item2.Afternoon.ToString());

                }
                foreach (Tuple<Incident, Dogs> data in IncidentData)
                {
                    incident.Rows.Add(data.Item2.Dogname, data.Item1.Info);
                }
            }
            else
            {
                MessageBox.Show("Appologies but the day care is closed on bank holidays and weekends", "Weekend or bankholiday selected");
            }
            dayCareSheet.DataSource = daily;
            staffTable.DataSource = staff;
            incidentTable.DataSource = incident;
        }

        private void dayCareSheet_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            base.IsWorkingOn = true;
        }

        private void dayCareSheet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if(dayCareSheet)
            if (dayCareSheet.SelectedRows.Count == 1)
            {
                this.Size = new Size(1102, 622);
                //show buttons and then extstend the screen
                foreach (Control x in this.Controls)
                {
                    if (x.Tag == "moveable")
                    {
                        x.Location = new Point(x.Location.X + 154, x.Location.Y);
                    }
                    if (x.Tag == "grayable") x.Visible = false;
                }
                CenterToScreen();
            }
            else
            {
                if (dayCareSheet.SelectedRows.Count == -1)
                {
                    //show buttons and then extstend the screen
                    foreach (Control x in this.Controls)
                    {
                        if (x.Tag == "moveable")
                        {
                            x.Location = new Point(x.Location.X - 154, x.Location.Y);
                        }
                        if (x.Tag == "grayable") x.Visible = false;
                    }
                    this.Size = new Size(948, 622);
                }
            }
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void dayCareSheet_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show(e.RowIndex.ToString());
            MessageBox.Show(e.ColumnIndex.ToString());
        }

        private void editInfo_Click(object sender, EventArgs e)
        {

            CenterToScreen();
        }

        private void addStaffBTN_Click(object sender, EventArgs e)
        {
            var form2 = new JDDogCare_2266.GUI.sub_menues.addNewStaff(Getdb);
            form2.ShowDialog();
        }

        private void IncidentLBL_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void CallToChildThread(DateTime datePicker, DataBase db)
        {
        }
        private void IncidentAddBTN_Click(object sender, EventArgs e)
        {
            var form2 = new JDDogCare_2266.GUI.sub_menues.addIncident(datePicker.Value,Getdb);
            form2.ShowDialog();
        }
        private void DailyCareMenu_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void StaffTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            //would have update the dogs to only show the relationship
        }

        private void IncidentTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //would have update the dogs to only show the relationship
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //save values
        }

        private void Print_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Print out of incidents is cutted", "ERROR COVID - 19");
        }

        public DateTime SelectedDate
        {
            get { return _selectedDate; }
            set { _selectedDate = value; }
        }
        public bool Exstended
        {
            get { return _exstended; }
            set { _exstended = value; }
        }
    }
}
