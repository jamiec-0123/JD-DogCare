﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using JDDogCare_2266.GUI;
using JDDogCare_2266.Objects;
using JDDogCare_2266.Validation;
using JDDogCare_2266.DBAccess;
namespace JDDogCare_2266.GUI
{
    public partial class paymentViewMenu : defaultScreen
    {
        private DataTable FeesTable;
        private BillingDBAccess BillingDB;
        List<Tuple<Booking, Billing, services, Client, Dogs, Repercussions>> billingData = new List<Tuple<Booking, Billing, services, Client, Dogs, Repercussions>>();
        int selectedRowIndex;
        bool selectedRow;
        public paymentViewMenu()
        {
            BillingDB = new BillingDBAccess(base.Getdb);
            billingData = BillingDB.getAllBillings();
            InitializeComponent();
        }

        private void UpdatePayment_Load(object sender, EventArgs e)
        {
            base.CurrentScreen = 7;
            FeesTable = new DataTable();
            FeesTable.Columns.Add("Client Name");
            FeesTable.Columns.Add("Dog Name");
            FeesTable.Columns.Add("Services Used");
            FeesTable.Columns.Add("Penaltys applied");
            foreach(Tuple<Booking, Billing, services, Client, Dogs, Repercussions> data in billingData)
            {
                FeesTable.Rows.Add(data.Item4.Clientname, data.Item5.Dogname, data.Item3.Info);
            }
            detailsDGV.DataSource = FeesTable;
        }
        public void updateTable()
        {
            selectedRow = false;
            for (int index = 0; index < detailsDGV.Rows.Count; index++)
            {
                if (detailsDGV.Rows[index].Selected == true && (index != 0 || index == selectedRowIndex))
                {
                    detailsDGV.Rows[index].Selected = false;
                    selectedRowIndex = -1;
                }
                else
                {
                    selectedRowIndex = index;
                    selectedRow = true;
                }
            }
            payedBTN.Checked = selectedRow;
        }
        private void DetailsDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            updateTable();
            if (selectedRowIndex != -1)
            {
             
                if (billingData[selectedRowIndex].Item2.DatePayed.ToString() == "01/01/1990")
                {
                    payedBTN.Checked = false;

                }
                else
                {
                    payedBTN.Checked = true;
                }
            }
        }

        private void PayedBTN_CheckedChanged(object sender, EventArgs e)
        {
            if (payedBTN.Checked == true)
            {
                BillingDB.updatePayment(billingData[selectedRowIndex].Item2.BillingID);
            }
            else
            {
                BillingDB.updatePayment(billingData[selectedRowIndex].Item2.BillingID, DateTime.Today);

            }
            MessageBox.Show("Updated");
            updateTable();
        }

        private void MaterialFlatButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Appologies, generating recepits is cut due to time constraints", "ERROR - COVID 19");
        }
    }
}
