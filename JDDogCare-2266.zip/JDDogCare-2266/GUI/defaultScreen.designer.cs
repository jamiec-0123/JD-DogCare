﻿namespace JDDogCare_2266.GUI
{
    partial class defaultScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(defaultScreen));
            this.mainMenueBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialDivider5 = new MaterialSkin.Controls.MaterialDivider();
            this.paymentBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.dbConnectionBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialDivider4 = new MaterialSkin.Controls.MaterialDivider();
            this.bookingBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.staffBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialDivider3 = new MaterialSkin.Controls.MaterialDivider();
            this.materialDivider2 = new MaterialSkin.Controls.MaterialDivider();
            this.trainingBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.mobservicesBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.walkingBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.collcNdelivBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.daycareBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.servicesBTN = new MaterialSkin.Controls.MaterialFlatButton();
            this.SuspendLayout();
            // 
            // mainMenueBTN
            // 
            this.mainMenueBTN.AutoSize = true;
            this.mainMenueBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.mainMenueBTN.Depth = 0;
            this.mainMenueBTN.Icon = null;
            this.mainMenueBTN.Location = new System.Drawing.Point(1, 521);
            this.mainMenueBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.mainMenueBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.mainMenueBTN.Name = "mainMenueBTN";
            this.mainMenueBTN.Primary = false;
            this.mainMenueBTN.Size = new System.Drawing.Size(100, 36);
            this.mainMenueBTN.TabIndex = 56;
            this.mainMenueBTN.Text = "Main Menu";
            this.mainMenueBTN.UseVisualStyleBackColor = true;
            this.mainMenueBTN.Click += new System.EventHandler(this.MainMenueBTN_Click);
            // 
            // materialDivider5
            // 
            this.materialDivider5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialDivider5.Depth = 0;
            this.materialDivider5.Location = new System.Drawing.Point(140, 65);
            this.materialDivider5.MouseState = MaterialSkin.MouseState.Hover;
            this.materialDivider5.Name = "materialDivider5";
            this.materialDivider5.Size = new System.Drawing.Size(10, 595);
            this.materialDivider5.TabIndex = 55;
            this.materialDivider5.Text = "materialDivider5";
            // 
            // paymentBTN
            // 
            this.paymentBTN.AutoSize = true;
            this.paymentBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.paymentBTN.Depth = 0;
            this.paymentBTN.Icon = null;
            this.paymentBTN.Location = new System.Drawing.Point(1, 465);
            this.paymentBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.paymentBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.paymentBTN.Name = "paymentBTN";
            this.paymentBTN.Primary = false;
            this.paymentBTN.Size = new System.Drawing.Size(87, 36);
            this.paymentBTN.TabIndex = 54;
            this.paymentBTN.Text = "Payment";
            this.paymentBTN.UseVisualStyleBackColor = true;
            this.paymentBTN.Click += new System.EventHandler(this.paymentBTN_Click);
            // 
            // dbConnectionBTN
            // 
            this.dbConnectionBTN.AutoSize = true;
            this.dbConnectionBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.dbConnectionBTN.Depth = 0;
            this.dbConnectionBTN.Icon = null;
            this.dbConnectionBTN.Location = new System.Drawing.Point(1, 569);
            this.dbConnectionBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dbConnectionBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.dbConnectionBTN.Name = "dbConnectionBTN";
            this.dbConnectionBTN.Primary = false;
            this.dbConnectionBTN.Size = new System.Drawing.Size(126, 36);
            this.dbConnectionBTN.TabIndex = 53;
            this.dbConnectionBTN.Text = "DISCONNECTED";
            this.dbConnectionBTN.UseVisualStyleBackColor = true;
            this.dbConnectionBTN.Click += new System.EventHandler(this.dbConnectionBTN_Click);
            // 
            // materialDivider4
            // 
            this.materialDivider4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialDivider4.Depth = 0;
            this.materialDivider4.Location = new System.Drawing.Point(0, 65);
            this.materialDivider4.MouseState = MaterialSkin.MouseState.Hover;
            this.materialDivider4.Name = "materialDivider4";
            this.materialDivider4.Size = new System.Drawing.Size(1551, 8);
            this.materialDivider4.TabIndex = 52;
            this.materialDivider4.Text = "materialDivider4";
            // 
            // bookingBTN
            // 
            this.bookingBTN.AutoSize = true;
            this.bookingBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bookingBTN.Depth = 0;
            this.bookingBTN.Icon = null;
            this.bookingBTN.Location = new System.Drawing.Point(1, 417);
            this.bookingBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.bookingBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.bookingBTN.Name = "bookingBTN";
            this.bookingBTN.Primary = false;
            this.bookingBTN.Size = new System.Drawing.Size(83, 36);
            this.bookingBTN.TabIndex = 51;
            this.bookingBTN.Text = "BOOKING";
            this.bookingBTN.UseVisualStyleBackColor = true;
            this.bookingBTN.Click += new System.EventHandler(this.bookingBTN_Click);
            // 
            // staffBTN
            // 
            this.staffBTN.AutoSize = true;
            this.staffBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.staffBTN.Depth = 0;
            this.staffBTN.Icon = null;
            this.staffBTN.Location = new System.Drawing.Point(1, 369);
            this.staffBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.staffBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.staffBTN.Name = "staffBTN";
            this.staffBTN.Primary = false;
            this.staffBTN.Size = new System.Drawing.Size(63, 36);
            this.staffBTN.TabIndex = 50;
            this.staffBTN.Text = "staff";
            this.staffBTN.UseVisualStyleBackColor = true;
            this.staffBTN.Click += new System.EventHandler(this.staffBTN_Click);
            // 
            // materialDivider3
            // 
            this.materialDivider3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialDivider3.Depth = 0;
            this.materialDivider3.Location = new System.Drawing.Point(-1, 357);
            this.materialDivider3.MouseState = MaterialSkin.MouseState.Hover;
            this.materialDivider3.Name = "materialDivider3";
            this.materialDivider3.Size = new System.Drawing.Size(151, 10);
            this.materialDivider3.TabIndex = 49;
            this.materialDivider3.Text = "materialDivider3";
            // 
            // materialDivider2
            // 
            this.materialDivider2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialDivider2.Depth = 0;
            this.materialDivider2.Location = new System.Drawing.Point(1, 512);
            this.materialDivider2.MouseState = MaterialSkin.MouseState.Hover;
            this.materialDivider2.Name = "materialDivider2";
            this.materialDivider2.Size = new System.Drawing.Size(150, 8);
            this.materialDivider2.TabIndex = 48;
            this.materialDivider2.Text = "materialDivider2";
            // 
            // trainingBTN
            // 
            this.trainingBTN.AutoSize = true;
            this.trainingBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.trainingBTN.Depth = 0;
            this.trainingBTN.Icon = null;
            this.trainingBTN.Location = new System.Drawing.Point(1, 309);
            this.trainingBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.trainingBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.trainingBTN.Name = "trainingBTN";
            this.trainingBTN.Primary = false;
            this.trainingBTN.Size = new System.Drawing.Size(118, 36);
            this.trainingBTN.TabIndex = 47;
            this.trainingBTN.Text = "dog training";
            this.trainingBTN.UseVisualStyleBackColor = true;
            this.trainingBTN.Click += new System.EventHandler(this.trainingBTN_Click);
            // 
            // mobservicesBTN
            // 
            this.mobservicesBTN.AutoSize = true;
            this.mobservicesBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.mobservicesBTN.BackColor = System.Drawing.Color.DarkSalmon;
            this.mobservicesBTN.Depth = 0;
            this.mobservicesBTN.Icon = null;
            this.mobservicesBTN.Location = new System.Drawing.Point(1, 215);
            this.mobservicesBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.mobservicesBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.mobservicesBTN.Name = "mobservicesBTN";
            this.mobservicesBTN.Primary = false;
            this.mobservicesBTN.Size = new System.Drawing.Size(139, 36);
            this.mobservicesBTN.TabIndex = 46;
            this.mobservicesBTN.Text = "mobile services";
            this.mobservicesBTN.UseVisualStyleBackColor = false;
            this.mobservicesBTN.Click += new System.EventHandler(this.mobservicesBTN_Click);
            // 
            // walkingBTN
            // 
            this.walkingBTN.AutoSize = true;
            this.walkingBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.walkingBTN.Depth = 0;
            this.walkingBTN.Icon = null;
            this.walkingBTN.Location = new System.Drawing.Point(1, 262);
            this.walkingBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.walkingBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.walkingBTN.Name = "walkingBTN";
            this.walkingBTN.Primary = false;
            this.walkingBTN.Size = new System.Drawing.Size(117, 36);
            this.walkingBTN.TabIndex = 45;
            this.walkingBTN.Text = "dog walking";
            this.walkingBTN.UseVisualStyleBackColor = true;
            this.walkingBTN.Click += new System.EventHandler(this.walkingBTN_Click);
            // 
            // collcNdelivBTN
            // 
            this.collcNdelivBTN.AutoSize = true;
            this.collcNdelivBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.collcNdelivBTN.Depth = 0;
            this.collcNdelivBTN.Icon = null;
            this.collcNdelivBTN.Location = new System.Drawing.Point(1, 168);
            this.collcNdelivBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.collcNdelivBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.collcNdelivBTN.Name = "collcNdelivBTN";
            this.collcNdelivBTN.Primary = false;
            this.collcNdelivBTN.Size = new System.Drawing.Size(206, 36);
            this.collcNdelivBTN.TabIndex = 44;
            this.collcNdelivBTN.Text = "Collection and delivery";
            this.collcNdelivBTN.UseVisualStyleBackColor = true;
            this.collcNdelivBTN.Click += new System.EventHandler(this.collcNdelivBTN_Click);
            // 
            // daycareBTN
            // 
            this.daycareBTN.AccessibleName = "dbButtonConnectTest";
            this.daycareBTN.AutoSize = true;
            this.daycareBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.daycareBTN.Depth = 0;
            this.daycareBTN.Icon = null;
            this.daycareBTN.Location = new System.Drawing.Point(1, 74);
            this.daycareBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.daycareBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.daycareBTN.Name = "daycareBTN";
            this.daycareBTN.Primary = false;
            this.daycareBTN.Size = new System.Drawing.Size(87, 36);
            this.daycareBTN.TabIndex = 43;
            this.daycareBTN.Text = "day care";
            this.daycareBTN.UseVisualStyleBackColor = true;
            this.daycareBTN.Click += new System.EventHandler(this.DaycareBTN_Click);
            // 
            // servicesBTN
            // 
            this.servicesBTN.AutoSize = true;
            this.servicesBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.servicesBTN.Depth = 0;
            this.servicesBTN.Icon = null;
            this.servicesBTN.Location = new System.Drawing.Point(1, 121);
            this.servicesBTN.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.servicesBTN.MouseState = MaterialSkin.MouseState.Hover;
            this.servicesBTN.Name = "servicesBTN";
            this.servicesBTN.Primary = false;
            this.servicesBTN.Size = new System.Drawing.Size(84, 36);
            this.servicesBTN.TabIndex = 42;
            this.servicesBTN.Text = "services";
            this.servicesBTN.UseVisualStyleBackColor = true;
            this.servicesBTN.Click += new System.EventHandler(this.servicesBTN_Click);
            // 
            // defaultScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 621);
            this.Controls.Add(this.mainMenueBTN);
            this.Controls.Add(this.materialDivider5);
            this.Controls.Add(this.paymentBTN);
            this.Controls.Add(this.dbConnectionBTN);
            this.Controls.Add(this.materialDivider4);
            this.Controls.Add(this.bookingBTN);
            this.Controls.Add(this.staffBTN);
            this.Controls.Add(this.materialDivider3);
            this.Controls.Add(this.materialDivider2);
            this.Controls.Add(this.trainingBTN);
            this.Controls.Add(this.mobservicesBTN);
            this.Controls.Add(this.walkingBTN);
            this.Controls.Add(this.collcNdelivBTN);
            this.Controls.Add(this.daycareBTN);
            this.Controls.Add(this.servicesBTN);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "defaultScreen";
            this.Text = "defaultScreen";
            this.Load += new System.EventHandler(this.DefaultScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialFlatButton mainMenueBTN;
        private MaterialSkin.Controls.MaterialDivider materialDivider5;
        private MaterialSkin.Controls.MaterialFlatButton paymentBTN;
        public MaterialSkin.Controls.MaterialFlatButton dbConnectionBTN;
        private MaterialSkin.Controls.MaterialDivider materialDivider4;
        private MaterialSkin.Controls.MaterialFlatButton bookingBTN;
        private MaterialSkin.Controls.MaterialFlatButton staffBTN;
        private MaterialSkin.Controls.MaterialDivider materialDivider3;
        private MaterialSkin.Controls.MaterialDivider materialDivider2;
        private MaterialSkin.Controls.MaterialFlatButton trainingBTN;
        private MaterialSkin.Controls.MaterialFlatButton mobservicesBTN;
        private MaterialSkin.Controls.MaterialFlatButton walkingBTN;
        private MaterialSkin.Controls.MaterialFlatButton collcNdelivBTN;
        private MaterialSkin.Controls.MaterialFlatButton daycareBTN;
        private MaterialSkin.Controls.MaterialFlatButton servicesBTN;
    }
}